-- phpMyAdmin SQL Dump
-- version 4.0.10.15
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 22, 2016 at 08:04 AM
-- Server version: 5.1.73
-- PHP Version: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `prod_documents`
--

-- --------------------------------------------------------

--
-- Table structure for table `AmountUseds`
--

CREATE TABLE IF NOT EXISTS `AmountUseds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `AmountUseds`
--

INSERT INTO `AmountUseds` (`id`, `name`, `retired`) VALUES
(1, 'Small (Milliliters)', 0),
(2, 'Medium (Liters)', 0),
(3, 'Large (Cubic Meters)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Controls`
--

CREATE TABLE IF NOT EXISTS `Controls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=142 ;

--
-- Dumping data for table `Controls`
--

INSERT INTO `Controls` (`id`, `name`, `retired`, `created_by`) VALUES
(1, 'Operators are fully trained in the use of the band saw.', 0, 17616),
(2, 'Safety gloves are to be worn when handling sharp material.', 0, 17616),
(3, 'Overalls are to be worn.', 0, 17616),
(4, 'Protective boots are to be worn. ', 0, 17616),
(5, 'All guards must be fully functional and in the correct place on the machine before the machine is started.', 0, 17616),
(6, 'Material must be fully secured in place using appropriate clamps before the saw is started. ', 0, 17616),
(7, 'Location of the emergency stop buttons will be clearly marked and known to the operator. ', 0, 17616),
(8, 'If the equipment is not in satisfactory working order it should not be used.', 0, 17616),
(9, 'All guards must be in place prior to starting the task.', 0, 17616),
(10, 'Swarf is to be removed using a brush and dust pan.', 0, 17616),
(11, 'All cutting operations will be carried out with cutting fluids.', 0, 17616),
(12, 'Suitable hearing protection will be provided for use in the area during cutting operations.', 0, 17616),
(13, 'All staff will keep the working area tidy, ensure walkways are not obstructed and remove trip hazards as and when they occur.', 0, 17616),
(14, 'Staff trained in correct lifting methods', 0, 17616),
(15, 'Lifting equipment provided where loads are heavy including sack / wheel barrows, FLT, chain or rope hoists where appropriate', 0, 17616),
(16, 'Team lifting to be used on awkward lifts', 0, 17616),
(17, 'The operator is responsible for ensuring other personnel and visitors remain clear of the machine whilst it is in operation. ', 0, 17616),
(18, 'Foreman is to ensure no one can access the area without permission.\r\nVisitors must be supervised at all times.', 0, 17616),
(19, 'Release the pre-tensioner before removing the blade, and reset after new blade has been put into place.', 0, 17616),
(20, 'Replace guards after blade is put into position.', 0, 17616),
(21, 'Stand away from the machine when first started in case of breakage. ', 0, 17616),
(22, 'All power tools and machinery must comply with Provision and Use of Work Equipment Regulations 1998.', 0, 17616),
(23, 'All employees must have received instruction in the safe use and operation of the equipment they are proposing to use.', 0, 17616),
(24, 'Eye protection must be worn at all times when there is a risk of flying parts, dust or fragments.', 0, 17616),
(25, 'All power tools and machinery must be regularly inspected and maintained in good condition.', 0, 17616),
(26, 'The power supply must be turned off before this task begins.', 0, 17616),
(27, 'Operator to wear cut resistant leather gloves.', 0, 17616),
(28, 'CAI working at height guidelines are followed on all projects.', 0, 17616),
(29, 'All staff must wear approved safety harnesses attached to secure safety lines whilst working at height.', 0, 17616),
(30, 'All staff are competent and experienced fitters.', 0, 17616),
(31, 'Installers will not work within 2 metres of an unprotected edge and will be attached to fall arrest systems at all times whilst working on roofs with unprotected edges.', 0, 17616),
(32, 'Correct equipment to be selected, provided and used for the work such as Mobile Elevating Work Platform (MEWP) or fixed scaffold to be erected. ', 0, 17616),
(33, 'Edge protection to be in place on scaffold in compliance with TG 20:08 to include hand and intermediate rails and toe boards.', 0, 17616),
(34, 'Only trained / licensed persons to use MEWPS.', 0, 17616),
(35, 'All ladders to be tied off or footed.', 0, 17616),
(36, 'All equipment to be removed from site / locked to prevent un-authorised access.', 0, 17616),
(37, 'The area below ladders where other persons may be liable to walk will be marked out with warning tape or barriers.', 0, 17616),
(38, 'If necessary a banks-man will be stationed to prevent pedestrians entering the work area.', 0, 17616),
(39, 'Installers have been instructed to take extra care when carrying tools at height, tool belts will be worn.', 0, 17616),
(40, 'Installers will only work from approved roof ladders and Youngermann Boards where necessary. Where work is required on pitched and flat roofs the installer will first determine the strength of the surface before accessing it.', 0, 17616),
(41, 'The installer is responsible for suspending work if weather conditions make the task unsafe.', 0, 17616),
(42, 'Good house keeping, working area to be kept clean and free from trip hazards such as wires for equipment.', 0, 17616),
(43, 'Walkways to be kept clear at all times.', 0, 17616),
(44, 'Safety footwear to be used at all times.', 0, 17616),
(45, 'Inspect tools for safety before use.', 0, 17616),
(46, 'Only competent persons to use power tools.', 0, 17616),
(47, 'Appropriate PPE to be worn including gloves, utility belt with fall restraint for tools and eyewear.', 0, 17616),
(48, 'Inform anyone who may be affected by the works.', 0, 17616),
(49, 'Put up notice to inform of men working overhead.', 0, 17616),
(50, 'Use bunting round working area outside, when on roof.', 0, 17616),
(52, 'Dual lifting to be used on awkward lifts.', 0, 17616),
(53, 'Suitable certified lifting equipment to be used when lifting aerials to roof, e.g. rope or chain hoists.', 0, 17616),
(54, 'All staff have received asbestos awareness training and have been instructed to stop work and report any suspicious materials.', 0, 17616),
(55, 'Project sites will have Demolition / Refurbishment survey report available for reference.', 0, 17616),
(56, 'Immediately isolate equipment from the main supply.', 0, 17616),
(57, 'Where noise levels are likely to be above 80 dB(A) the competent person must carry out a noise assessment and the employer must provide hearing protection if asked for by employees.', 0, 17616),
(58, 'Where noise levels are likely to be above 85 dB(A) the employer must reduce the exposure to noise of employees other than by the provision of hearing protection.\r\n', 0, 17616),
(59, 'All staff must wear the appropriate ear defenders in noisy areas.', 0, 17616),
(60, 'Plan to maintain the equipment in good condition at all times.', 0, 17616),
(61, 'Use the equipment as per manufacturers’ recommendations.', 0, 17616),
(62, 'Use only qualified personnel to service / repair the equipment.', 0, 17616),
(63, 'Ensure all guards are in place and are not damaged.', 0, 17616),
(65, 'All employees and contractors must have received instruction in the safe use and operation of the equipment they are proposing to use.', 0, 17616),
(67, 'All staff will keep the working area tidy and remove trip hazards as and when they occur.', 0, 17616),
(68, 'All staff will wear suitable footwear at all times.', 0, 17616),
(69, 'Horseplay is strictly forbidden. Do not direct air onto skin or allow nozzle to come into direct contact with the body.', 0, 17616),
(70, 'Ensure all hosepipes are securely connected before switching on the machine.', 0, 17616),
(71, 'Do not wear loose clothing, control long hair.', 0, 17616),
(74, 'Staff have been instructed to take extra care when carrying tools at height, tool belts will be worn.', 0, 17616),
(75, 'The area below ladders and scaffold where other person may be liable to walk will be marked out with warning tape or barriers, and persons prevented from traveling across the danger area.', 0, 17616),
(76, 'If necessary a banks-man will be stationed at ground level to prevent pedestrians from entering the danger area.', 0, 17616),
(77, 'Materials will be passed up by hand and secured to prevent rolling or blowing off.', 0, 17616),
(78, 'Staff to be issued with appropriate PPE including waterproofs, coats and gloves as appropriate to conditions.', 0, 17616),
(79, 'The site foreman is responsible for suspending work if weather conditions make the task unsafe.', 0, 17616),
(80, 'Ensure safety of electrical equipment in wet weather as unsuitable equipment can easily become live and make its surroundings live.', 0, 17616),
(81, 'Take account of weather conditions, wear appropriate clothing and take warm drinks in cold weather, cover up or apply sun block to prevent sunburn.', 0, 17616),
(83, 'Lifting / transport equipment provided where loads are heavy include barrows or hoists where appropriate.', 0, 17616),
(84, 'Team lifting to be used on heavy and awkward lifts.', 0, 17616),
(85, 'All personnel have been deemed competent to carry out works required of them.', 0, 17616),
(86, 'Young workers and apprentices will be supervised whilst on site.', 0, 17616),
(87, 'All staff will be inducted onto site and follow all main contractor safety rules.', 0, 17616),
(88, 'Hazardous areas must signposted, barricaded and, where appropriate, covered to avoid possible injury to workers and members of the public.', 0, 17616),
(89, 'Anyone who may be affected by the works to be informed of site work, especially tenants and other contractors.', 0, 17616),
(90, 'Foreman is to ensure no one access site without permit, or permission.', 0, 17616),
(91, 'The site will be made safe at the end of each shift.', 0, 17616),
(92, 'All personnel are trained and experienced in working at height.', 0, 17616),
(93, 'Asbestos is highly dangerous.  Any asbestos-containing materials on site should have been identified before work starts.', 0, 17616),
(94, 'Refurbishment and demolition surveys will be required where refurbishment work or other work involving disturbing the fabric of the building is to be carried out.', 0, 17616),
(95, 'All operatives have been trained on an annual basis in the safe removal of non licensed  asbestos containing materials.', 0, 17616),
(96, 'All asbestos-containing materials on site should have been identified before work starts.\r\n', 0, 17616),
(97, 'All ACMs will be examined and their condition determined prior to starting work, very dusty or flaky ACMs will be reported to the competent person.', 0, 17616),
(98, 'All asbestos containing materials - ACMs - will be double bagged and sealed. All ACMs will be removed from site by licensed waste carriers.', 0, 17616),
(101, 'All operatives are face fitted for full and / or half face masks. RPE must be worn at all times during asbestos removal works.', 0, 17616),
(102, 'Disposable overalls must be used for carrying out works and on completion a specific clean down procedure must be completed to decontaminate and prevent inhalation of any asbestos dust. Contaminated PPE must be collected and bagged for authorised disposal.', 0, 17616),
(103, 'If you suspect you have found asbestos. Place signs around the work area warning people not to enter the work area.', 0, 17616),
(104, 'Clearly mark the designated boundary by barricading, fencing or similar. If safe to do so lock out any air heating and ventilation systems to prevent extending any area of suspected contamination and contact your supervisor who will arrange sampling and air monitoring. Levels must be below 0.1fibres per ml of air.', 0, 17616),
(105, 'Before entering or re-entering a site where asbestos has been removed final air clearance measurements of airborne asbestos contaminants will be carried out by competent persons.\r\n\r\nWhen clearance has been given the site supervisor will make results available to all workers before entry to site.', 0, 17616),
(106, 'Should not be used if asbestos is likely to be disturbed – Use hand tools only.', 0, 17616),
(107, 'Power tools will not be left unattended.\r\nThe site will be made safe at the end of each shift.', 0, 17616),
(108, 'Staff will follow the method statement devised for this task.', 0, 17616),
(111, 'All power tools and machinery must be inspected and maintained in good condition, and should be inspected by the user prior to use for visual defects. ', 0, 17616),
(112, 'Faulty equipment must be withdrawn from service for repair or replacement.', 0, 17616),
(113, 'Only trained and experienced operatives are allowed to use Power tools, inexperienced or young workers are kept under strict supervision whilst using power tools.', 0, 17616),
(114, 'Battery powered tools are used where possible.', 0, 17616),
(115, 'Company power tools are PAT tested on an annual basis.', 0, 17616),
(116, 'A Hepa 1 rated (double filtered) vacuum system should be used.', 0, 17616),
(117, 'Company ladders inspected on a regular basis and defects reported, damaged ladders removed from site and replaced.', 0, 17616),
(118, 'All staff are experienced, trained and competent to carry out ladder work.', 0, 17616),
(119, 'Young/inexperienced staff are trained and closely supervised during step ladder work.', 0, 17616),
(120, 'Step Ladders will not be used where an onsite risk assessment has determined that the residual risk with all controls in place is still too high.', 0, 17616),
(121, 'Ensure that all sub contractors have the relevant training, qualifications and insurance in place.', 0, 17616),
(122, 'Ensure all tools to be used are in good condition i.e. no loose or damaged parts.', 0, 17616),
(123, 'All hand tools are kept in tool bags/boxes when not in use.', 0, 17616),
(124, 'Ensure the correct tool is used for the task e.g. do not use screwdrivers as chisels.', 0, 17616),
(125, 'Any tools used must be decontaminated before returning them to the tool box.', 0, 17616),
(126, 'All personnel must attend Site Induction prior to commencing works.', 0, 17616),
(127, 'It is vitally important that potentially hazardous areas are signposted, barricaded and, where appropriate, covered to avoid possible injury to workers and members of the public.', 0, 17616),
(129, 'Site to be secured to prevent un-authorised access.', 0, 17616),
(130, 'Staff will cordon off work areas and ensure tenants do not enter area of danger.', 0, 17616),
(131, 'Any asbestos containing materials that have been removed must be stored as hazardous waste and the possibility of fibre release eliminated by placing the debris or waste into thick plastic bags or directly into purpose made skips.', 0, 17616),
(132, 'All staff have been trained in correct lifting methods.', 0, 17616),
(133, 'Assess the best way to lift, with the maximum weight nearest the body.', 0, 17616),
(134, 'Ensure that the route to be taken while lifting is clear of any obstructions.', 0, 17616),
(135, 'Team lifting to be used when loads are heavy or awkward.', 0, 17616),
(136, 'The site foreman shall be responsible for identifying and controlling manual handling issues on site.', 0, 17616),
(137, 'Mechanical lifting equipment should be provided where loads are heavy. ', 0, 17616),
(140, 'Ensure cable, hose or air lines do not cause trip hazards.', 0, 17616),
(141, 'Ensure that all access and egress routes are kept clear and tidy and that all fire\r\nescape routes are free from obstruction.', 0, 17616);

-- --------------------------------------------------------

--
-- Table structure for table `CoshhAssessments`
--

CREATE TABLE IF NOT EXISTS `CoshhAssessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `supplied_by` text,
  `assessor` varchar(255) DEFAULT NULL,
  `supervisor` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `method_of_use` varchar(255) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `AmountUseds_id` int(11) DEFAULT NULL,
  `TimePerDays_id` int(11) DEFAULT NULL,
  `Durations_id` int(11) DEFAULT NULL,
  `general_precautions` text NOT NULL,
  `first_aid_measures` text,
  `further_controls` text,
  `responsibility` varchar(255) DEFAULT NULL,
  `by_when` varchar(255) DEFAULT NULL,
  `spillage_procedure` text NOT NULL,
  `fire_prevention` text,
  `handling_storage` text,
  `disposal_procedure` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `comments` text,
  PRIMARY KEY (`id`),
  KEY `AmountUseds_id` (`AmountUseds_id`),
  KEY `TimePerDays_id` (`TimePerDays_id`),
  KEY `Durations_id` (`Durations_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `CoshhAssessments`
--

INSERT INTO `CoshhAssessments` (`id`, `name`, `reference`, `supplied_by`, `assessor`, `supervisor`, `description`, `method_of_use`, `location`, `AmountUseds_id`, `TimePerDays_id`, `Durations_id`, `general_precautions`, `first_aid_measures`, `further_controls`, `responsibility`, `by_when`, `spillage_procedure`, `fire_prevention`, `handling_storage`, `disposal_procedure`, `created_at`, `updated_at`, `created_by`, `retired`, `comments`) VALUES
(1, 'Daily Kitchen Inspection', 'Ref Number', 'Supplied By', 'Assessor', 'And supervisor', '<p>A desc</p>\r\n', '<p>A Method</p>\r\n', 'A location', 2, 3, 2, '<p><strong>Lorem Ipsum</strong> is simply dummy text of the prhing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<p>Why do we use it?</p>\n\n<p>It is a long established fact that a reader will be distracted by the readab9;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<p>Why do we use it?</p>\n\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p><strong>Why do we use it?</strong></p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', 'Someone must be resposnible', 'By tomrrow', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<p>Why do we use it?</p>\n\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<p>Why do we use it?</p>\n\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '2016-07-11 15:17:07', NULL, 13508, 0, '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<p>Why do we use it?</p>\n\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n');

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_Mel`
--

CREATE TABLE IF NOT EXISTS `Coshh_Mel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `Eh40s_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `Eh40s_id` (`Eh40s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Coshh_Mel`
--

INSERT INTO `Coshh_Mel` (`id`, `CoshhAssessments_id`, `Eh40s_id`) VALUES
(5, 1, 7),
(6, 1, 21),
(7, 1, 32),
(8, 1, 42);

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_Oes`
--

CREATE TABLE IF NOT EXISTS `Coshh_Oes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `Eh40s_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `Eh40s_id` (`Eh40s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Coshh_Oes`
--

INSERT INTO `Coshh_Oes` (`id`, `CoshhAssessments_id`, `Eh40s_id`) VALUES
(5, 1, 1),
(6, 1, 2),
(7, 1, 3),
(8, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_PersonsAffected`
--

CREATE TABLE IF NOT EXISTS `Coshh_PersonsAffected` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `PersonRisks_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `PersonRisks_id` (`PersonRisks_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `Coshh_PersonsAffected`
--

INSERT INTO `Coshh_PersonsAffected` (`id`, `CoshhAssessments_id`, `PersonRisks_id`) VALUES
(2, 1, 2),
(3, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_Ppes`
--

CREATE TABLE IF NOT EXISTS `Coshh_Ppes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `Ppes_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `Ppes_id` (`Ppes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Coshh_Ppes`
--

INSERT INTO `Coshh_Ppes` (`id`, `CoshhAssessments_id`, `Ppes_id`) VALUES
(5, 1, 1),
(6, 1, 3),
(7, 1, 4),
(8, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_RiskPhrases`
--

CREATE TABLE IF NOT EXISTS `Coshh_RiskPhrases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `RiskPhrases_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `RiskPhrases_id` (`RiskPhrases_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Coshh_RiskPhrases`
--

INSERT INTO `Coshh_RiskPhrases` (`id`, `CoshhAssessments_id`, `RiskPhrases_id`) VALUES
(5, 1, 1),
(6, 1, 6),
(7, 1, 24),
(8, 1, 25);

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_RouteEntrys`
--

CREATE TABLE IF NOT EXISTS `Coshh_RouteEntrys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `RouteEntrys_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `RouteEntrys_id` (`RouteEntrys_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Coshh_RouteEntrys`
--

INSERT INTO `Coshh_RouteEntrys` (`id`, `CoshhAssessments_id`, `RouteEntrys_id`) VALUES
(1, 1, 1),
(2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_Substances`
--

CREATE TABLE IF NOT EXISTS `Coshh_Substances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `Substances_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `Substances_id` (`Substances_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Coshh_Substances`
--

INSERT INTO `Coshh_Substances` (`id`, `CoshhAssessments_id`, `Substances_id`) VALUES
(5, 1, 2),
(6, 1, 4),
(7, 1, 7),
(8, 1, 9);

-- --------------------------------------------------------

--
-- Table structure for table `Coshh_Wel`
--

CREATE TABLE IF NOT EXISTS `Coshh_Wel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CoshhAssessments_id` int(11) NOT NULL,
  `Eh40s_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CoshhAssessments_id` (`CoshhAssessments_id`),
  KEY `Eh40s_id` (`Eh40s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Coshh_Wel`
--

INSERT INTO `Coshh_Wel` (`id`, `CoshhAssessments_id`, `Eh40s_id`) VALUES
(5, 1, 5),
(6, 1, 97),
(7, 1, 124),
(8, 1, 225);

-- --------------------------------------------------------

--
-- Table structure for table `Durations`
--

CREATE TABLE IF NOT EXISTS `Durations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `Durations`
--

INSERT INTO `Durations` (`id`, `name`, `retired`) VALUES
(1, '1 - 5 Minutes', 0),
(2, '6 - 30 Minutes', 0),
(3, '31 - 60 Minutes', 0),
(4, '1 Hour & Above', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Eh40s`
--

CREATE TABLE IF NOT EXISTS `Eh40s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `substance` varchar(255) NOT NULL,
  `cas_number` varchar(255) DEFAULT NULL,
  `long_ppm` varchar(255) DEFAULT NULL,
  `long_mgm3` varchar(255) DEFAULT NULL,
  `short_ppm` varchar(255) DEFAULT NULL,
  `short_mgm3` varchar(255) DEFAULT NULL,
  `comments` text,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=444 ;

--
-- Dumping data for table `Eh40s`
--

INSERT INTO `Eh40s` (`id`, `substance`, `cas_number`, `long_ppm`, `long_mgm3`, `short_ppm`, `short_mgm3`, `comments`, `retired`) VALUES
(1, 'Acetaldehyde', '75-07-0', '20', '37', '50', '92', '', 0),
(2, 'Acetic anhydride', '108-24-7', '0.5', '2.5', '2', '10', '', 0),
(3, 'Acetone', '67-64-1', '500', '1210', '1500', '3620', '', 0),
(4, 'Acetonitrile', '75-05-8', '40', '68', '60', '102', '', 0),
(5, 'o-Acetylsalicylic acid', '50-78-2', '', '5', '', '', '', 0),
(6, 'Acrylaldehyde (Acrolein)', '107-02-8', '0.1', '0.23', '0.3', '0.7', '', 0),
(7, 'Acrylamide', '79-06-1', '', '0.3', '', '', 'Carc, Sk', 0),
(8, 'Acrylonitrile', '107-13-1', '2', '4.4', '', '', 'Carc, Sk', 0),
(9, 'Allyl alcohol', '107-18-6', '2', '4.8', '4', '9.7', 'Sk', 0),
(10, 'Aluminium alkyl compounds', '', '', '2.5', '', '', '', 0),
(11, 'Aluminium metal inhalable dust', '7429-90-5', '', '10', '', '', '', 0),
(12, 'Aluminium metal respirable dust', '7429-90-5', '', '4', '', '', '', 0),
(13, 'Aluminium oxides inhalable dust', '1344-28-1', '', '10', '', '', '', 0),
(14, 'Aluminium oxides respirable dust', '1344-28-1', '', '4', '', '', '', 0),
(15, 'Aluminium salts, soluble', '', '', '2.5', '', '', '', 0),
(16, '2-Aminoethanol', '141-43-5', '1', '2.5', '3', '7.6', 'sk', 0),
(17, 'Ammonia, anhydrous', '7664-41-7', '25', '18', '35', '25', '', 0),
(18, 'Ammonium chloride, fume', '12125-02-9', '', '10', '', '20', '', 0),
(19, 'Ammonium sulphamidate', '7773-06-0', '', '10', '', '20', '', 0),
(20, 'Aniline', '62-53-3', '1', '4', '', '', '', 0),
(21, 'Antimony and compounds except stibine (as Sb)', '', '', '0.5', '', '', '', 0),
(22, 'r-Aramid respirable fibres', '26125-61-1', '0.5 fibres/ml', '', '', '', '', 0),
(23, 'Arsenic and arsenic compounds except arsine (as As)', '', '', '0.1', '', '', 'Carc, Sk', 0),
(24, 'Arsine', '7784-42-1', '0.05', '0.16', '', '', '', 0),
(25, 'Asphalt, petroleum fumes', '8052-42-4', '', '5', '', '10', '', 0),
(26, 'Azodicarbonamide', '123-77-3', '', '1.0', '', '3.0', 'Sen', 0),
(27, 'Barium compounds, soluble (as Ba)', '', '', '0.5', '', '', '', 0),
(28, 'Barium sulphate inhalable dust', '7727-43-7', '', '10', '', '', '', 0),
(29, 'Barium sulphate respirable dust', '7727-43-7', '', '4', '', '', 'Carc, Sk', 0),
(30, 'Benzene', '71-43-2', '1', '3.25', '', '', '', 0),
(31, 'Benzyl butyl phthalate', '85-68-7', '', '5', '1.5', '7.9', 'Carc', 0),
(32, 'Benzyl chloride', '100-44-7', '0.5', '2.6', '', '', 'Carc', 0),
(33, 'Beryllium and beryllium compounds (as Be)', '', '', '0.002', '', '10', '', 0),
(34, 'Bis(2-ethylhexyl) phthalate', '117-81-7', '', '5', '', '', 'Carc', 0),
(35, 'Bis(chloromethyl) ether', '542-88-1', '0.001', '0.005', '', '', '', 0),
(36, 'Bisphenol A inhalable dust', '80-05-7', '', '10', '3', '19', '', 0),
(37, 'Bornan-2-one', '77-22-2', '2', '13', '', '', '', 0),
(38, 'Boron tribromide', '10294-33-4', '', '', '1', '10', '', 0),
(39, 'Bromacil (ISO)', '314-40-9', '1', '11', '2', '22', '', 0),
(40, 'Bromine', '7726-95-6', '0.1', '0.66', '0.2', '1.3', '', 0),
(41, 'Bromomethane', '74-83-9', '5', '20', '15', '59', 'SK', 0),
(42, 'Butane', '106-97-8', '600', '1450', '750', '1810', 'Carc, (only applies if Butane contains more than 0.1% of buta-1,3-diene)', 0),
(43, 'Buta-1,3-diene', '106-99-0', '10', '22', '', '', 'Carc', 0),
(44, 'Butan-1-ol', '71-36-3', '', '', '50', '154', 'sk', 0),
(45, 'Butan-2-ol', '78-92-2', '100', '308', '150', '462', '', 0),
(46, 'Butan-2-one (methyl ethyl ketone)', '78-93-3', '200', '600', '300', '899', '', 0),
(47, '2-Butoxyethanol', '111-76-2', '25', '123', '50', '246', '', 0),
(48, '2-(2-Butoxyethoxy) ethanol', '112-34-5', '10', '67.5', '15', '101.2', '', 0),
(49, '2-Butoxyethyl acetate', '112-07-2', '200', '133', '50', '332', '', 0),
(50, 'n-Butyl acrylate', '141-32-2', '1', '5', '50', '26', '', 0),
(51, 'n-Butyl chloroformate', '592-34-7', '1', '5.7', '', '', '', 0),
(52, 'sec-Butyl acetate', '105-46-4', '200', '966', '250', '1210', '', 0),
(53, 'tert-Butyl acetate', '540-88-5', '200', '966', '250', '1210', '', 0),
(54, 'Butyl acetate', '123-86-4', '150', '724', '200', '966', '', 0),
(55, 'Butyl lactate', '138-22-7', '5', '308', '', '', '', 0),
(56, '2-sec-Butylphenol', '89-72-5', '5', '31', '', '', 'Sk', 0),
(57, 'Cadmium and cadmium compounds except cadmium oxide fume, cadmium sulphide and cadmium sulphide pigments (as Cd) ', '', '', '0.025', '', '', 'Carc (cadmium metal, cadmium chloride, fluoride and sulphate)', 0),
(58, 'Cadmium oxide fume (as Cd)', '1306-19-0', '', '0.025', '', '0.05', 'Carc', 0),
(59, 'Cadmium sulphide and cadmium sulphide pigments (respirable dust (as Cd))', '', '', '0.03', '', '', 'Carc (cadmium sulphide)', 0),
(60, 'Caesium hydroxide', '21351-79-1', '', '2.5', '', '', '', 0),
(61, 'Calcium carbonate inhalable dust', '1317-65-3', '', '10', '', '', '', 0),
(62, 'Calcium carbonate respirable', '1317-65-3', '', '4', '', '', '', 0),
(63, 'Calcium cyanamide', '156-62-7', '', '0.5', '', '1.3', '', 0),
(64, 'Calcium hydroxide', '1305-62-0', '', '5', '', '', '', 0),
(65, 'Calcium oxide', '1305-78-8', '', '2.5', '', '', '', 0),
(66, 'Calcium silicate inhalable dust', '1344-95-2', '', '10', '', '', '', 0),
(67, 'Calcium silicate respirable', '1344-95-2', '', '4', '', '', '', 0),
(68, 'Captan (ISO)', '133-06-2', '', '5', '', '15', '', 0),
(69, 'Carbon black', '1333-86-4', '', '3.5', '', '7', '', 0),
(70, 'Carbon dioxide', '124-38-9', '5000', '9150', '15000', '27400', '', 0),
(71, 'Carbon disulphide', '75-15-0', '5', '15', '', '', 'Sk', 0),
(72, 'Carbon monoxide', '630-08-0', '30', '35', '200', '232', 'BMGV', 0),
(73, 'Carbon tetrachloride', '56-23-5', '2', '13', '', '', 'Sk', 0),
(74, 'Cellulose inhalable dust', '9004-34-6', '', '10', '', '20', '', 0),
(75, 'Cellulose respirable', '9004-34-6', '', '4', '', '', '', 0),
(76, 'Chlorine', '7782-50-5', '', '', '0.5', '1.5', '', 0),
(77, 'Chlorine dioxide', '10049-04-4', '0.1', '0.28', '0.3', '0.84', '', 0),
(78, 'Chloroacetaldehyde', '107-20-0', '', '', '1', '3.3', '', 0),
(79, '2-Chloroacetophenone', '532-27-4', '0.05', '0.32', '', '', '', 0),
(80, 'Chlorobenzene', '108-90-7', '1', '4.7', '3', '14', 'Sk', 0),
(81, 'Chlorodifluoromethane', '75-45-6', '1000', '3590', '', '', '', 0),
(82, 'Chloroethane', '75-00-3', '5000', '134', '', '', '', 0),
(83, '2-Chloroethanol', '107-07-3', '', '', '1', '3.4', 'Sk', 0),
(84, '1-Chloro-2,3- epoxypropane (Epichlorohydrin)', '106-89-8', '0.5', '1.9', '1.5', '5.8', 'Carc', 0),
(85, 'Chloroform', '67-66-3', '2', '9.9', '', '', 'Sk', 0),
(86, 'Chloromethane', '74-87-3', '50', '105', '100', '210', '', 0),
(87, '1-Chloro-4-nitrobenzene', '100-00-5', '', '1.0', '', '20', 'Sk', 0),
(88, 'Chlorosulphonic acid', '7790-94-5', '', '1.0', '', '', '', 0),
(89, 'Chlorpyrifos (ISO)', '2921-88-2', '', '0.2', '', '0.6', 'Sk', 0),
(90, 'Chromium', '7440-47-3', '', '0.5', '', '', '', 0),
(91, 'Chromium (II) compounds (as Cr)', '', '', '0.5', '', '', '', 0),
(92, 'Chromium (III) compounds (as Cr)', '', '', '0.5', '', '', '', 0),
(93, 'Chromium (VI) compounds (as Cr)', '', '', '0.05', '', '', 'Carc, sen, BMGV', 0),
(94, 'Cobalt and Cobalt compounds (as Co)', '', '', '0.1', '', '', 'Carc (cobalt dichloride and sulphate), Sen', 0),
(95, 'Copper fume (as Cu)', '7440-50-8', '', '0.2', '', '', '', 0),
(96, 'Copper and compounds: dust and mists (as Cu)', '', '', '1', '', '2', '', 0),
(97, 'Cotton dust', '(see paras 19 - 21)', '', '2.5', '', '', '', 0),
(98, 'Cryofluorane (INN)', '76-14-2', '1000', '7110', '1250', '8890', '', 0),
(99, 'Cumene', '98-82-8', '25', '125', '50', '250', 'Sk', 0),
(100, 'Cyanamide', '420-04-2', '0.58', '1', '', '', 'Sk', 0),
(101, 'Cyanides, except HCN, cyanogen and cyanogen chloride (as Cn)', '', '', '5', '', '', 'Sk', 0),
(102, 'Cyanogen chloride', '506-77-4', '', '', '0.3', '0.77', '', 0),
(103, 'Cyclohexane', '110-82-7', '100', '350', '300', '1050', '', 0),
(104, 'Cyclohexanol', '108-93-0', '50', '208', '', '', '', 0),
(105, 'Cyclohexanone', '108-94-1', '10', '41', '200', '82', 'Sk, BMGV', 0),
(106, 'Cyclohexylamine', '108-91-8', '10', '41', '', '', '', 0),
(107, '2,4-D (ISO)', '94-75-7', '', '10', '', '20', '', 0),
(108, 'Dialkyl 79 phthalate', '83968-18-7', '', '5', '', '', '', 0),
(109, 'Diallyl phthalate', '131-17-9', '', '5', '', '', '', 0),
(110, 'Diatomaceous earth, natural, respirable dust', '61790-53-2', '', '102', '', '', '', 0),
(111, 'Dibenzoyl peroxide', '94-36-0', '', '5', '', '', '', 0),
(112, 'Dibismuth tritelluride', '1304-82-1', '', '10', '', '20', '', 0),
(113, 'Diboron trioxide', '1303-86-2', '', '10', '', '20', '', 0),
(114, '1,2-Dibromoethane (Ethylene dibromide)', '106-93-4', '0.5', '3.9', '', '', 'Carc, Sk', 0),
(115, 'Dibutyl hydrogen phosphate', '107-66-4', '1', '8.7', '2', '17', '', 0),
(116, 'Dibutyl phthalate', '84-74-2', '', '5', '', '10', '', 0),
(117, 'Dichloroacetylene', '7572-29-4', '', '', '0.1', '0.39', '', 0),
(118, '1,2-Dichlorobenzene (ortho-dichlorobenzene)', '95-50-1', '25', '153', '50', '306', '', 0),
(119, '1,4 Dichlorobenzene (para-dichlorobenzene)', '106-46-7', '25', '153', '50', '306', '', 0),
(120, '1,3-Dichloro-5,5-dimethyl-hydantoin', '118-52-5', '', '0.2', '', '0.4', '', 0),
(121, '1,1-Dichloroethane', '75-34-3', '100', '', '', '', '', 0),
(122, '1,2-Dichloroethane (Ethylene dichloride)', '107-06-2', '5', '21', '', '', '', 0),
(123, '1,2-Dichloroethylene, cis:trans isomers 60:40', '540-59-0', '200', '806', '250', '1010', '', 0),
(124, 'Dichlorofluoromethane', '75-43-4', '10', '43', '', '', '', 0),
(125, 'Dichloromethane', '75-09-2', '100', '350', '300', '1060', 'BMGV, Sk', 0),
(126, '2,2’-Dichloro-4,4’-methylene dianiline (MbOCA)', '101-14-4', '', '0.005', '', '', 'Carc, Sk, BMGV', 0),
(127, 'Dicyclohexyl phthalate', '84-61-7', '', '5', '', '', '', 0),
(128, 'Dicyclopentadiene', '77-73-6', '5', '27', '', '', '', 0),
(129, 'Diethylamine', '109-89-7', '5', '15', '100', '306', '', 0),
(130, 'Diethyl ether', '60-29-7', '100', '310', '200', '620', '', 0),
(131, 'Diethyl phthalate', '84-66-2', '', '5', '', '10', '', 0),
(132, 'Diethyl sulphate', '64-67-5', '0.05', '0.32', '', '', 'Carc, Sk', 0),
(133, 'Dihydrogen selenide (as Se)', '7783-07-5', '0.02', '0.07', '0.05', '0.17', '', 0),
(134, 'Diisobutyl phthalate', '84-69-5', '', '5', '', '', '', 0),
(135, 'Diisodecyl phthalate', '26761-40-0', '', '5', '', '', '', 0),
(136, 'Diisononyl phthalate', '28553-12-0', '', '5', '', '', '', 0),
(137, 'Diisooctyl phthalate', '27554-26-3', '', '5', '', '', '', 0),
(138, 'Diisopropylamine', '108-18-9', '5', '21', '', '', '', 0),
(139, 'Diisopropyl ether', '108-20-3', '250', '1060', '310', '1310', '', 0),
(140, 'N,N-Dimethylacetamide', '127-19-5', '10', '36', '20', '72', '', 0),
(141, 'N,N-Dimethylaniline', '121-69-7', '5', '25', '10', '50', '', 0),
(142, 'N,N-Dimethylethylamine', '598-56-1', '10', '308', '15', '46', '', 0),
(143, 'Dimethoxymethane', '109-87-5', '1000', '3160', '1250', '3950', '', 0),
(144, 'Dimethylamine', '124-40-3', '2', '3.8', '6', '11', '', 0),
(145, '2-Dimethylaminoethanol', '108-01-0', '2', '7.4', '6', '22', '', 0),
(146, 'Dimethyl ether', '115-10-6', '400', '766', '500', '958', '', 0),
(147, 'N,N-Dimethylformamide', '68-12-2', '5', '15', '10', '306', '', 0),
(148, '2,6-Dimethylheptan-4-one', '108-83-8', '25', '148', '', '', '', 0),
(149, 'Dimethyl phthalate', '131-11-3', '', '5', '', '10', '', 0),
(150, 'Dimethyl sulphate', '77-78-1', '0.05', '0.26', '', '', '', 0),
(151, 'Dinitrobenzene, all isomers', '25154-54-5', '0.15', '1', '0.5', '3.5', '', 0),
(152, 'Dinonyl phthalate', '84-76-4', '', '5', '', '', '', 0),
(153, '1,4-Dioxane', '123-91-1', '200', '73', '', '', '', 0),
(154, 'Diphenylamine', '122-39-4', '', '10', '', '20', '', 0),
(155, 'Diphenyl ether (vapour)', '101-84-8', '1', '7.1', '', '', '', 0),
(156, 'Diphosphorus pentasulphide', '1314-80-3', '', '1', '', '2', '', 0),
(157, 'Disphosphorus pentoxide', '1314-56-3', '', '1', '', '2', '', 0),
(158, 'Diquat dibromide (ISO)', '85-00-7', '', '0.5', '', '1', '', 0),
(159, 'Disodium disulphite', '7681-57-4', '', '5', '', '', '', 0),
(160, 'Disodium tetraborate, anhydrous', '1330-43-4', '', '1', '', '', '', 0),
(161, 'Disodium tetraborate, decahydrate', '1330-96-4', '', '5', '', '', '', 0),
(162, 'Disodium tetraborate, pentahydrate', '11130-12-4', '', '1', '', '', '', 0),
(163, 'Disulphur dichloride', '10025-67-9', '', '', '1', '5.6', '', 0),
(164, '2,6-Di-tert-butyl-p-cresol', '128-37-0', '', '10', '', '', '', 0),
(165, '6,6’-Di-tert-butyl-4,4’-thiodi-m-cresol', '96-69-5', '', '10', '', '20', '', 0),
(166, 'Diuron (ISO)', '330-54-1', '', '10', '', '', '', 0),
(167, 'Emery inhalable dust', '1302-74-5', '', '10', '', '', '', 0),
(168, 'Emery respirable', '1302-74-5', '', '4', '', '', '', 0),
(169, 'Endosulfan (ISO)', '115-29-7', '', '0.1', '', '0.3', 'sk', 0),
(170, 'Enflurane', '13838-16-9', '50', '383', '', '', '', 0),
(171, 'Ethane-1,2-diol particulate', '107-21-1', '', '10', '', '', 'sk', 0),
(172, 'Ethane-1,2-diol vapour', '107-21-1', '200', '52', '40', '104', 'sk', 0),
(173, 'Ethanethiol', '75-08-1', '0.5', '1.3', '2', '5.2', '', 0),
(174, 'Ethanol', '64-17-5', '1000', '1320', '', '', '', 0),
(175, '2-Ethoxyethanol', '110-80-5', '2', '8', '', '', 'sk', 0),
(176, '2-Ethoxyethyl acetate', '111-15-9', '2', '11', '', '', 'sk', 0),
(177, '2-Ethylhexyl chloroformate', '24468-13-1', '1', '8', '', '', '', 0),
(178, 'Ethyl acetate', '141-78-6', '200', '', '400', '', '', 0),
(179, 'Ethyl acrylate', '140-88-5', '5', '21', '10', '42', '', 0),
(180, 'Ethylamine', '75-04-7', '2', '3.8', '6', '11', '', 0),
(181, 'Ethylbenzene', '100-41-4', '100', '441', '125', '552', 'sk', 0),
(182, 'Ethyl chloroformate', '541-41-3', '1', '4.5', '', '', '', 0),
(183, 'Ethyl cyanoacrylate', '7085-85-0', '', '', '0.3', '1.5', '', 0),
(184, 'Ethyl formate', '109-94-4', '100', '308', '150', '462', '', 0),
(185, 'Ethylene oxide', '75-21-8', '5', '9.2', '', '', 'Carc', 0),
(186, '4-Ethylmorpholine', '100-74-3', '5', '24', '20', '96', 'sk', 0),
(187, 'Ferrous foundry particulate inhalable dust', 'See paras 22-24', '', '10', '', '', '', 0),
(188, 'Ferrous foundry particulate respirable dust', 'See paras 22-24', '', '4', '', '', '', 0),
(189, 'Flour dust', 'See para 25', '', '10', '', '30', 'Sen', 0),
(190, 'Fluoride (inorganic as F)', '16984-48-8', '', '2.5', '', '', '', 0),
(191, 'Fluorine', '7782-41-4', '1', '1.6', '1', '1.6', '', 0),
(192, 'Formaldehyde', '50-00-0', '2', '2.5', '2', '2.5', '', 0),
(193, 'Formamide', '75-12-7', '200', '37', '30', '56', '', 0),
(194, 'Formic acid', '64-18-6', '5', '9.6', '', '', '', 0),
(195, '2-Furaldehyde (furfural)', '98-01-1', '2', '28', '5', '20', 'sk', 0),
(196, 'Germane', '7782-65-2', '0.2', '0.64', '0.6', '1.9', '', 0),
(197, 'Glutaraldehyde', '111-30-8', '0.05', '0.2', '0.05', '0.2', '', 0),
(198, 'Glycerol, mist', '56-81-5', '', '10', '', '', '', 0),
(199, 'Grain dust ', 'See para 26', '', '10', '', '', 'Sen', 0),
(200, 'Graphite inhalable dust', '7440-44-0', '', '10', '', '', '', 0),
(201, 'Graphite respirable', '7440-44-0', '', '4', '', '', '', 0),
(202, 'Gypsum inhalable dust', '10101-41-4', '', '10', '', '', '', 0),
(203, 'Gypsum respirable', '10101-41-4', '', '4', '', '', '', 0),
(204, 'Halogeno-platinum compounds (complex co-ordination compounds in which the platinum atom is directly co-ordinated to halide groups) (as Pt)', 'See paras 27-28', '', '0.002', '', '', 'Sen', 0),
(205, 'Halothane', '151-67-7', '10', '82', '', '', '', 0),
(206, 'Hardwood dust', 'See paras 41-42', '', '5', '', '', 'Carc, Sen', 0),
(207, 'n-Heptane', '142-82-5', '5000', '2085', '', '', '', 0),
(208, 'Heptan-2-one', '110-43-0', '50', '237', '100', '475', 'Sk', 0),
(209, 'Heptan-3-one', '106-35-4', '35', '166', '100', '475', 'Sk', 0),
(210, 'n-Hexane', '110-54-3', '200', '72', '', '', '', 0),
(211, '1,6-Hexanolactam dust only', '105-60-2', '', '1', '', '3', '', 0),
(212, '1,6-Hexanolactam dust and vapour', '105-60-2', '', '10', '', '20', '', 0),
(213, 'Hexan-2-one', '591-78-6', '5', '21', '', '', 'Sk', 0),
(214, 'Hydrazine', '302-01-2', '0.02', '0.03', '0.1', '0.13', 'Carc, Sk', 0),
(215, 'Hydrogen bromide', '10035-10-6', '', '', '3', '10', '', 0),
(216, 'Hydrogen chloride (gas and aerosol mists)', '7647-01-0', '1', '2', '5', '8', '', 0),
(217, 'Hydrogen cyanide', '74-90-8', '', '', '10', '11', '', 0),
(218, 'Hydrogen fluoride (as F)', '7664-39-3', '1.8', '1.5', '3', '2.5', 'Sk', 0),
(219, 'Hydrogen peroxide', '7722-84-1', '1', '1.4', '2', '2.8', '', 0),
(220, 'Hydrogen sulphide', '7783-06-4', '5', '7', '10', '14', '', 0),
(221, 'Hydroquinone', '123-31-9', '', '0.5', '', '', '', 0),
(222, '4-Hydroxy-4-methylpentan-2-one', '123-42-2', '50', '241', '75', '3620', '', 0),
(223, '2-Hydroxypropyl acrylate', '999-61-1', '0.5', '2.7', '', '', 'Sk', 0),
(224, '2,2’-Iminodi(ethylamine)', '111-40-0', '1', '4.3', '', '', 'Sk', 0),
(225, 'Indene', '95-13-6', '10', '48', '15', '72', '', 0),
(226, 'Indium and compounds (as In)', '', '', '0.1', '0', '0.3', '', 0),
(227, 'Iodine', '7553-56-2', '', '', '0.1', '1.1', '', 0),
(228, 'Iodoform', '75-47-8', '0.6', '9.8', '1', '16', '', 0),
(229, 'Iodomethane', '74-88-4', '2', '12', '', '', '', 0),
(230, 'Iron oxide, fume (as Fe)', '1309-37-1', '', '5', '', '10', '', 0),
(231, 'Iron salts (as Fe)', '', '', '1', '', '2', '', 0),
(232, 'Isobutyl acetate', '110-19-0', '150', '724', '187', '903', '', 0),
(233, 'Isocyanates, all (as –NCO) Except methyl isocyanate', '', '', '0.02', '', '0.07', 'Sen', 0),
(234, 'Isoflurane', '26675-46-7', '50', '383', '', '', '', 0),
(235, 'Isoocytl alcohol (mixed isomers)', '26952-21-6', '50', '271', '', '', '', 0),
(236, 'Isopentane', '78-78-4', '600', '1800', '', '', '', 0),
(237, 'Isopropyl acetate', '108-21-4', '', '', '200', '849', '', 0),
(238, 'Isopropyl chloroformate', '108-23-6', '1', '5.1', '', '', '', 0),
(239, 'Kaolin, respirable dust', '1332-58-7', '', '2', '', '', '', 0),
(240, 'Ketene', '463-51-4', '0.5', '0.87', '1.5', '2.6', '', 0),
(241, 'Limestone total inhalable', '1317-65-3', '', '10', '', '', '', 0),
(242, 'Limestone respirable', '1317-65-3', '', '4', '', '', '', 0),
(243, 'Liquefied petroleum gas', '68476-85-7', '1000', '1750', '1250', '2180', 'Carc (only applies if LPG contains more than 0.1% of buta-1,3-diene)', 0),
(244, 'Lithium hydride', '7580-67-8', '', '0.025', '', '', '', 0),
(245, 'Lithium hydroxide', '1310-65-2', '', '', '', '1', '', 0),
(246, 'Magnesite inhalable dust', '546-93-0', '', '10', '', '', '', 0),
(247, 'Magnesite respirable dust', '546-93-0', '', '4', '', '', '', 0),
(248, 'Magnesium oxide (as Mg) inhalable dust', '1309-48-4', '', '10', '', '', '', 0),
(249, 'Magnesium oxide (as Mg) fume and respirable Dust', '1309-48-4', '', '4', '', '', '', 0),
(250, 'Malathion (ISO)', '121-75-5', '', '10', '', '', 'Sk', 0),
(251, 'Maleic anhydride', '108-31-6', '', '1', '', '3', 'Sen', 0),
(252, 'Manganese and its inorganic compounds (as Mn)', '', '', '0.5', '', '', '', 0),
(253, 'Marble total inhalable', '1317-65-3', '', '10', '', '', '', 0),
(254, 'Marble respirable', '1317-65-3', '', '4', '', '', '', 0),
(255, 'Mercaptoacetic acid', '68-11-1', '1', '3.8', '', '', '', 0),
(256, 'Mercury and divalent inorganic compounds including mercuric oxide and mercuric chloride (measured as mercury)', '', '', '0.02', '', '', '', 0),
(257, 'Methacrylic acid', '79-41-4', '200', '72', '40', '143', '', 0),
(258, 'Methacrylonitrile', '126-98-7', '1', '2.8', '', '', 'Sk', 0),
(259, 'Methanethiol', '74-93-1', '0.5', '1.0', '', '', '', 0),
(260, 'Methanol', '67-56-1', '200', '266', '250', '333', 'Sk', 0),
(261, '2-Methoxyethanol', '109-86-4', '1', '3.25', '', '', 'Sk', 0),
(262, '2-(2-Methoxyethoxy) ethanol', '111-77-3', '10', '50.1', '', '', 'Sk', 0),
(263, '2-Methoxyethyl acetate', '110-49-6', '1', '5', '', '', 'Sk', 0),
(264, '(2-methoxymethylethoxy) propanol', '34590-94-8', '50', '308', '', '', 'Sk', 0),
(265, '1-Methoxypropan-2-ol', '107-98-2', '100', '375', '150', '560', 'Sk', 0),
(266, '1-Methoxypropyl acetate', '108-65-6', '50', '274', '100', '548', 'Sk', 0),
(267, 'Methyl acetate', '79-20-9', '200', '616', '250', '770', '', 0),
(268, 'Methyl acrylate', '96-33-3', '5', '18', '10', '36', '', 0),
(269, '3-Methylbutan-1-ol', '123-51-3', '100', '366', '125', '458', '', 0),
(270, 'Methyl cyanoacrylate', '137-05-3', '', '', '0.3', '1.4', '', 0),
(271, '4,4’-Methylenedianiline', '101-77-9', '0.01', '0.08', '', '', 'Carc, Sk, GMGV', 0),
(272, 'Methyl ethyl ketone peroxides (MEKP)', '1338-23-4', '', '', '0.2', '1.5', '', 0),
(273, 'Methyl methacrylate', '80-62-6', '50', '208', '100', '416', '', 0),
(274, '2-Methylcyclohexanone', '583-60-8', '50', '233', '75', '350', '', 0),
(275, 'Methylcyclohexanol', '25639-42-3', '50', '237', '75', '356', '', 0),
(276, 'Methyl isocyanate (as –NCO)', '624-83-9', '', '', '0.02', '', 'Sen', 0),
(277, 'N-Methylaniline', '100-61-8', '0.5', '2.2', '', '', 'Sk', 0),
(278, 'n-Methyl-2-pyrrolidone', '872-50-4', '10', '40', '20', '80', 'Sk', 0),
(279, '5-Methylheptan-3-one', '541-85-5', '10', '53', '20', '107', '', 0),
(280, '5-Methylhexan-2-one', '110-12-3', '200', '95', '100', '475', 'Sk', 0),
(281, '2-Methylpentane-2,4-diol', '107-41-5', '25', '123', '250', '123', '', 0),
(282, '4-Methylpentan-2-ol', '108-11-2', '25', '106', '40', '170', 'Sk', 0),
(283, '4-Methylpentan-2-one', '108-10-1', '50', '208', '100', '416', 'Sk, BMGV', 0),
(284, '2-Methylpropan-1-ol', '78-83-1', '50', '154', '75', '231', '', 0),
(285, '2-Methylpropan-2-ol', '75-65-0', '100', '308', '150', '462', '', 0),
(286, 'Methyl-tert-butyl-ether', '1634-04-4', '50', '183.5', '10', '367', '', 0),
(287, 'Mica total inhalable', '12001-26-2', '', '10', '', '', '', 0),
(288, 'Mica respirable', '12001-26-2', '', '0.87', '', '', '', 0),
(289, 'MMMF (Machine-made mineral fibre) (except for refractory ceramic fibres and special purpose fibres)', '', '5mg. M -3 and 2 fibres/Millilitre', '', '', '', '', 0),
(290, 'Molybdenum compounds (as Mo) soluble compounds', '', '', '5', '', '10', '', 0),
(291, 'Molybdenum compounds (as Mo) insoluble compounds', '', '', '10', '', '20', '', 0),
(292, 'Monochloroacetic acid', '79-11-8', '0.3', '1.2', '', '', 'Sk', 0),
(293, 'Morpholine', 'Morpholine', '10', '36', '', '72', 'Sk', 0),
(294, 'Neopentane', 'Neopentane', '600', '1800', '', '', '', 0),
(295, 'Nickel and its inorganic compounds (except nickel tetracarbonyl): water-soluble nickel compounds (as Ni)', '', '', '0.1', '', '', 'Sk, Carc (nickel oxides and sulphides) Sen (nickel sulphate)', 0),
(296, 'Nickel and its inorganic compounds (except nickel tetracarbonyl): nickel and water-insoluble nickel compounds (as Ni)', '', '', '0.5', '', '', 'Sk, Carc (nickel oxides and sulphides) Sen (nickel sulphate)', 0),
(297, 'Nicotine', '54-11-5', '', '0.5', '', '1.5', 'Sk', 0),
(298, 'Nitric acid', '7697-37-2', '', '', '1', '2.6', '', 0),
(299, 'Nitrobenzene', '98-95-3', '0.2', '1', '', '', 'Sk', 0),
(300, 'Nitromethane', '75-52-5', '100', '254', '150', '381', '', 0),
(301, '2-Nitropropane', '79-46-9', '5', '19', '', '', 'Carc', 0),
(302, 'Nitrous oxide', '10024-97-2', '100', '183', '', '', '', 0),
(303, 'Orthophosphoric acid', '7664-38-2', '', '1', '', '2', '', 0),
(304, 'Osmium tetraoxide (as Os)', '20816-12-0', '0.0002', '0.002', '0.0006', '0.006', '', 0),
(305, 'Oxalic acid', '144-62-7', '', '1', '', '2', '', 0),
(306, '2,2’-Oxydiethanol', '111-46-6', '23', '101', '', '', '', 0),
(307, 'Ozone', '10028-15-6', '', '', '0.2', '0.4', '', 0),
(308, 'Paracetamol, inhalable dust', '103-90-2', '', '10', '', '', '', 0),
(309, 'Paraffin wax, fume', '8002-74-2', '', '2', '', '620', '', 0),
(310, 'Paraquat dichloride (ISO), respirable dust', '1910-42-5', '', '0.08', '', '', '', 0),
(311, 'Pentacarbonyliron (as Fe)', '13463-40-6', '0.01', '0.08', '', '', '', 0),
(312, 'Pentaerythritol inhalable dust', '115-77-5', '', '10', '', '20', '', 0),
(313, 'Pentaerythritol respirable dust', '115-77-5', '', '4', '', '', '', 0),
(314, 'Pentan-2-one', '107-87-9', '200', '716', '250', '895', '', 0),
(315, 'Pentan-3-one', '96-22-0', '200', '716', '250', '895', '', 0),
(316, 'Pentane', '109-66-0', '600', '1800', '', '', '', 0),
(317, 'Pentyl acetates (all isomers)', '', '50', '270', '100', '541', '', 0),
(318, '2-Phenylpropene', '98-83-9', '50', '246', '100', '491', '', 0),
(319, 'Phenol', '108-95-2', '2', '7.8', '4', '16', 'Sk', 0),
(320, 'p-Phenylenediamine', '106-50-3', '', '0.1', '', '', 'Sk', 0),
(321, 'Phorate (ISO)', '298-02-2', '', '0.05', '', '0.2', 'Sk', 0),
(322, 'Phosgene', '75-44-5', '0.02', '0.08', '0.06', '0.25', '', 0),
(323, 'Phosphine', '7803-51-2', '0.1', '0.14', '0.2', '0.28', '', 0),
(324, 'Phosphorus pentachloride', '10026-13-8', '0.1', '0.87', '0.2', '2', '', 0),
(325, 'Phosphorus trichloride', '7719-12-2', '0.2', '1.1', '0.5', '2.9', '', 0),
(326, 'Phosphorus, yellow', '7723-14-0', '', '0.1', '', '0.3', '', 0),
(327, 'Phosphoryl trichloride', '10025-87-3', '0.2', '1.3', '0.6', '3.8', '', 0),
(328, 'Phthalic anhydride', '85-44-9', '', '4', '', '12', '', 0),
(329, 'Picloram (ISO)', '1918-02-1', '', '10', '', '20', '', 0),
(330, 'Picric acid', '88-89-1', '', '0.1', '', '0.3', '', 0),
(331, 'Piperazine', '110-85-0', '', '0.1', '', '0.3', 'Sen', 0),
(332, 'Piperazine dihydrochloride', '142-64-3', '', '0.1', '', '0.3', 'Sen', 0),
(333, 'Piperidine', '110-89-4', '1', '3.5', '', '', 'Sk', 0),
(334, 'Plaster of Paris inhalable dust', '26499-65-0', '', '10', '', '', '', 0),
(335, 'Plaster of Paris respirable dust', '26499-65-0', '', '4', '', '', '', 0),
(336, 'Platinum compounds, soluble (except certain halogeno-Pt compounds) (as Pt)', '', '', '0.002', '', '', '', 0),
(337, 'Platinum metal', '7440-06-4', '', '5', '', '', '', 0),
(338, 'Polychlorinated biphenyls (PCB)', '1336-36-3', '', '0.1', '', '', 'Sk', 0),
(339, 'Polyvinyl chloride inhalable dust', '9002-86-2', '', '10', '', '', '', 0),
(340, 'Polyvinyl chloride respirable dust', '9002-86-2', '', '4', '', '', '', 0),
(341, 'Portland cement inhalable dust', '65997-15-1', '', '0.002', '', '', '', 0),
(342, 'Portland cement respirable dust', '65997-15-1', '', '4', '', '', '', 0),
(343, 'Potassium hydroxide', '1310-58-3', '', '', '', '2', '', 0),
(344, 'Propane-1,2-diol total vapour and particulates', '57-55-6', '150', '474', '', '', '', 0),
(345, 'Propane-1,2-diol particulates', '57-55-6', '', '10', '', '', '', 0),
(346, 'Propan-1-ol', '71-23-8', '200', '500', '250', '625', 'Sk', 0),
(347, 'Propan-2-ol', '67-63-0', '400', '3999', '500', '1250', '', 0),
(348, 'Propionic acid', '79-09-4', '10', '31', '15', '46', '', 0),
(349, 'Propoxur (ISO)', '114-26-1', '', '0.5', '', '2', '', 0),
(350, 'Propranolol', '525-66-6', '', '2', '', '6', '', 0),
(351, 'n-Propyl acetate', '109-60-4', '200', '849', '250', '1060', '', 0),
(352, 'Propylene oxide', '75-56-9', '5', '12', '', '', 'Carc', 0),
(353, 'Prop-2-yn-1-ol', '107-19-7', '1', '2.3', '3', '7', 'Sk', 0),
(354, 'Pulverised fuel ash inhalable dust', '', '', '10', '', '', '', 0),
(355, 'Pulverised fuel ash respirable dust', '', '', '4', '', '', '', 0),
(356, 'Pyrethrum (purified of sensitising lactones)', '8003-34-7', '', '1', '', '', '', 0),
(357, 'Pyridine', '110-86-1', '0.5', '166', '10', '332', '', 0),
(358, '2-Pyridylamine', '504-29-0', '', '2', '2', '7.8', '', 0),
(359, 'Pyrocatechol', '102-80-9', '5', '233', '', '', '', 0),
(360, 'Refractory ceramic fibres and special purpose fibres', '', '5mg.m -3 1 fibre/millilitre', '5mg.m -3 1 fibre/millilitre', '', '', 'Carc', 0),
(361, 'Resorcinol', '108-46-3', '10', '46', '20', '92', 'Sk', 0),
(362, 'Rhodium (as Rh) metal fume and dust', '', '', '0.1', '', '0.3', '', 0),
(363, 'Rhodium (as Rh) soluble salts', '', '', '0.001', '', '0.003', '', 0),
(364, 'Rosin-based solder flux fume', '8050-09-7', '', '0.05', '', '0.15', 'Sen', 0),
(365, 'Rotenone (ISO)', '83-79-4', '', '5', '', '10', '', 0),
(366, 'Rouge total inhalable', '1309-37-1', '', '10', '', '', '', 0),
(367, 'Rouge respirable', '1309-37-1', '', '4', '', '', '', 0),
(368, 'Rubber fume', 'See paras 33-37', '', '0.64', '', '', 'Carc, limit relates to cyclohexane soluble material', 0),
(369, 'Rubber process dust', 'See paras 33-37', '', '600', '', '', 'Carc', 0),
(370, 'Selenium and compounds, except hydrogen selenide (as Se)', '', '', '0.1', '', '', '', 0),
(371, 'Silane', '7803-62-5', '0.5', '0.67', '1', '1.3', '', 0),
(372, 'Silica, amorphous inhalable dust', '', '', '600', '', '', '', 0),
(373, 'Silica, amorphous respirable dust', '', '', '2.4', '', '', '', 0),
(374, 'Silica, respirable crystalline', '', '', '0.1', '', '', '', 0),
(375, 'Silica, fused respirable dust', '60676-86-0', '', '0.08', '', '', '', 0),
(376, 'Silicon inhalable dust', '7440-21-3', '', '10', '', '', '', 0),
(377, 'Silicon respirable dust', '7440-21-3', '', '4', '', '', '', 0),
(378, 'Silicon carbide respirable dust (not whiskers) total inhalable', '409-21-2', '', '10', '', '', '', 0),
(379, 'Silicon carbide respirable dust (not whiskers) respirable', '409-21-2', '', '4', '', '', '', 0),
(380, 'Silver (soluble compounds as Ag)', '', '', '0.01', '', '', '', 0),
(381, 'Silver, metallic', '7440-22-4', '', '0.1', '', '', '', 0),
(382, 'Sodium azide (as NaN 3 )', '26628-22-8', '', '0.1', '', '0.3', 'Sk', 0),
(383, 'Sodium 2- (2,4-dichlorophenoxy) ethyl sulphate', '136-78-7', '', '10', '', '20', '', 0),
(384, 'Sodium hydrogen sulphite', '7631-90-5', '', '5', '', '', '', 0),
(385, 'Sodium hydroxide', '1310-73-2', '', '', '', '2', '', 0),
(386, 'Softwood dust', 'See paras 41 - 42', '', '5', '', '', 'Sen', 0),
(387, 'Starch total inhalable', '9005-25-8', '', '10', '', '', '', 0),
(388, 'Starch respirable', '9005-25-8', '', '4', '', '', '', 0),
(389, 'Styrene', '100-42-5', '100', '430', '250', '1080', '', 0),
(390, 'Subtilisins', '1395-21-7 (Bacillus subtilis BPN) 9014-01-1 (Bacillus Subtilis Carlsberg) ', '', '0.00004', '', '', 'Sen', 0),
(391, 'Sucrose', '57-50-1', '', '10', '', '20', '', 0),
(392, 'Sulfotep (ISO)', '3689-24-5', '', '0.1', '', '', '', 0),
(393, 'Sulphur hexafluoride', '2551-62-4', '1000', '6070', '1250', '7590', '', 0),
(394, 'Sulphuric acid (mist)', '7664-93-9', '', '0.05', '', '', 'The mist is defined as the thoracic fraction', 0),
(395, 'Sulphuryl difluoride', '2699-79-8', '5', '21', '10', '42', '', 0),
(396, 'Talc, respirable dust', '14807-96-6', '', '1', '', '', '', 0),
(397, 'Tantalum', '7440-25-7', '', '5', '', '10', '', 0),
(398, 'Tellurium and compounds, except hydrogen telluride (as Te)', '', '', '0.1', '', '', '', 0),
(399, 'Terphenyls, all isomers', '26140-60-3', '', '', '0.5', '4.8', '', 0),
(400, '1,1,2,2-Tetrabromoethane', '79-27-6', '0.5', '7.2', '', '', 'Sk', 0),
(401, 'Tertiary-butyl-methyl-Ether', '1634-04-4', '50', '183.5', '100', '367', '', 0),
(402, 'Tetracarbonylnickel (as Ni)', '13463-39-3', '', '', '0.1', '0.24', '', 0),
(403, 'Tetrachloroethylene', '127-18-4', '50', '345', '100', '689', '', 0),
(404, '1,1,1,2-Tetrafluoroethane (HFC 134a)', '811-97-2', '1000', '4240', '', '', '', 0),
(405, 'Tetrahydrofuran', '109-99-9', '50', '150', '100', '300', 'SK', 0),
(406, 'Tetrasodium pyrophosphate', '7722-88-5', '', '5', '', '', '', 0),
(407, 'Thallium, soluble compounds (as TI)', '', '', '0.1', '', '', 'Sk', 0),
(408, 'Thionyl chloride', '7719-09-7', '', '', '1', '4.9', '', 0),
(409, 'Tin compounds, inorganic except SnH 4 , (as Sn)', '', '', '2', '', '4.8', '', 0),
(410, 'Tin compounds, organic, except Cyhexatin (ISO), (as Sn)', '', '', '0.1', '', '0.2', 'Sk', 0),
(411, 'Titanium dioxide total inhalable', '13463-67-7', '', '10', '', '', '', 0),
(412, 'Titanium dioxide respirable', '13463-67-7', '', '4', '', '', '', 0),
(413, 'Toluene', '108-88-3', '50', '191', '100', '384', 'Sk', 0),
(414, 'P-Toluenesulphonyl chloride', '98-59-9', '', '', '', '5', '', 0),
(415, 'o-Toluidine', '95-53-4', '0.2', '0.89', '', '', 'Carc, Sk', 0),
(416, 'Tributyl phosphate, all isomers', '126-73-8', '', '5', '', '5', '', 0),
(417, '1,2,4-Trichlorobenzene', '120-82-1', '1', '', '5', '', 'Sk', 0),
(418, '1,1,1-Trichloroethane', '71-55-6', '100', '555', '200', '1110', '', 0),
(419, 'Trichloroethylene', '79-01-6', '100', '550', '150', '820', 'Carc, Sk', 0),
(420, 'Trichloronitromethane', '76-06-2', '0.1', '0.68', '0.3', '2.1', '', 0),
(421, 'Triethylamine', '121-44-8', '2', '8', '4', '17', 'Sk', 0),
(422, 'Triglycidyl isocyanurate (TGIC)', '2451-62-9', '', '0.1', '', '', 'Carc', 0),
(423, 'Trimellitic anhydride', '552-30-7', '', '0.04', '', '0.12', 'Sen', 0),
(424, 'Trimethylbenzenes, all isomers or mixtures', '25551-13-7', '25', '125', '', '', '', 0),
(425, '3,5,5-trimethylcyclohex-2-enone', '78-59-1', '', '', '5', '29', '', 0),
(426, 'Trimethyl phosphite', '121-45-9', '2', '10', '', '', '', 0),
(427, '2,4,6-Trinitrotoluene', '118-96-7', '', '0.5', '', '', 'Sk', 0),
(428, 'Tri-o-tolyl phosphate', '78-30-8', '', '0.1', '', '0.3', '', 0),
(429, 'Triphenyl phosphate', '115-86-6', '', '3.25', '', '6', '', 0),
(430, 'Tungsten and compounds (as W) soluble compounds', '7440-33-7', '', '1', '', '3', '', 0),
(431, 'Tungsten and compounds (as W) insoluble compounds and others', '7440-33-7', '', '5', '', '10', '', 0),
(432, 'Turpentine', '8006-64-2', '100', '566', '150', '850', '', 0),
(433, 'Vanadium pentoxide', '1314-62-1', '', '0.05', '', '', '', 0),
(434, 'Vinyl acetate', '108-05-4', '5', '17.6', '10', '35.2', '', 0),
(435, 'Vinyl chloride', '75-01-4', '30', '7.8', '', '', 'Carc', 0),
(436, 'Vinylidene chloride', '75-35-4', '10', '40', '', '', '', 0),
(437, 'Wool process dust', 'See para 43', '', '10', '', '', '', 0),
(438, 'Xylene, o-,m-,p- or mixed isomers', '1330-20-7', '50', '220', '100', '441', 'Sk, BMGV', 0),
(439, 'Yttrium', '7440-65-5', '', '1', '', '3', '', 0),
(440, 'Zinc chloride, fume', '7646-85-7', '', '1', '', '2', '', 0),
(441, 'Zinc distearate inhalable dust', '557-05-1', '', '10', '', '20', '', 0),
(442, 'Zinc distearate respirable dust', '557-05-1', '', '4', '', '', '', 0),
(443, 'Zirconium compounds (as Zr)', '', '', '5', '', '10', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Hazards`
--

CREATE TABLE IF NOT EXISTS `Hazards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `Hazards`
--

INSERT INTO `Hazards` (`id`, `name`, `description`, `created_by`, `created_at`, `updated_by`, `updated_at`, `retired`) VALUES
(1, 'Working at height from ladders/MEWPS etc. Risk of death or major injury', 'Working at height from ladders/MEWPS etc. Risk of death or major injury', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(2, 'Dropping equipment from height leading to injury of persons on the ground', 'Dropping equipment from height leading to injury of persons on the ground', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(3, 'Working on fragile surfaces', 'Working on fragile surfaces', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(4, 'Working In adverse weather conditions', 'Working In adverse weather conditions', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(5, 'Slips trips and falls', 'Slips trips and falls', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(6, 'Working with power tools and battery powered tools\r\n', 'Working with power tools and battery powered tools\r\n', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(7, 'Injury to Tenants / householder from installation operations', 'Injury to Tenants / householder from installation operations', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(8, 'Manual Handling', 'Manual Handling', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(9, 'Illness from exposure from Asbestos', 'Illness from exposure from Asbestos', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(10, 'Electrocution due to damage to the equipment', 'Electrocution due to damage to the equipment', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(11, 'Noise', 'Noise', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(12, 'Fire, heat, burns & injuries from compressor', 'Fire, heat, burns & injuries from compressor', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(13, 'Injection of compressed air', 'Injection of compressed air', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(14, 'Whiplash, involuntary disconnection of airline', 'Whiplash, involuntary disconnection of airline', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(15, 'Trapping/ entanglement', 'Trapping/ entanglement', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(16, 'Injury from incorrect manual handling', 'Injury from incorrect manual handling', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(17, 'Hung up Workers', 'Hung up Workers', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(18, 'Dropping equipment from height leading to injury of persons on the ground', 'Dropping equipment from height leading to injury of persons on the ground', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(19, 'Occupational asthma from breathing solder fumes', 'Occupational asthma from breathing solder fumes', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(20, 'Working with power tools and battery powered tools', 'Working with power tools and battery powered tools', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(21, 'Injury to Tenants / householder from installation operations', 'Injury to Tenants / householder from installation operations', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(22, 'Illness from exposure from Asbestos', 'Illness from exposure from Asbestos', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(23, 'Fire from Hot work', 'Fire from Hot work', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(24, 'Injury to other construction workers and members of the public during operations.', 'Injury to other construction workers and members of the public during operations.', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(25, 'Contact with Electricity', 'Contact with Electricity', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(26, 'Using R12 and R13 refrigerant gasses', 'Using R12 and R13 refrigerant gasses', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(27, 'Mobile plant & transport', 'Mobile plant & transport', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(28, 'Inclement Weather', 'Inclement Weather', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(29, 'Working on construction and refurbishment sites', 'Working on construction and refurbishment sites', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(30, 'Access & Use;\r\nFalls, collapse,', 'Access & Use;\r\nFalls, collapse,', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(31, 'Asbestos/ \r\nCarcinogens and\r\nIllness from  exposure to asbestos', 'Asbestos/ \r\nCarcinogens and\r\nIllness from  exposure to asbestos', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(32, 'Falls from stepladders leading to death, major injury', 'Falls from stepladders leading to death, major injury', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(33, 'Poor Training: General accident potential increased.', 'Poor Training: General accident potential increased.', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(34, 'Operation Band Saw. Leading to loss of limbs or digits, cuts or other serious injury', 'Operation Band Saw. Leading to loss of limbs or digits, cuts or other serious injury', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(35, 'Swarf ejection.', 'Swarf ejection.', 17616, '2016-07-20 16:01:30', NULL, NULL, 0),
(36, 'Blade change.', 'Blade change.', 17616, '2016-07-20 16:01:30', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Headers`
--

CREATE TABLE IF NOT EXISTS `Headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `Types_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Types_id` (`Types_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=129 ;

--
-- Dumping data for table `Headers`
--

INSERT INTO `Headers` (`id`, `name`, `description`, `created_by`, `retired`, `Types_id`) VALUES
(1, 'Falling from height - (List Type)', 'Falling from height.', 17616, 0, 1),
(2, 'Injury from incorrect Manual handling - (List Type)', 'Injury from incorrect Manual handling.', 17616, 0, 1),
(3, 'Contact dermatitis from exposure to wet concrete and dust. - (List Type)', 'Contact dermatitis from exposure to wet concrete and dust.', 17616, 0, 1),
(4, 'Disease from standing/stagnant water. - (List Type)', 'Disease from standing/stagnant water.', 17616, 0, 1),
(5, 'Injury from the incorrect actions of other contractors on site. -(List Type)', 'Injury from the incorrect actions of other contractors on site.', 17616, 0, 1),
(6, 'Injury to members of the public during operations. -(List Type)', 'Injury to members of the public during operations.', 17616, 0, 1),
(7, 'Injury from machine hazards. -(List Type)', 'Injury from machine hazards.', 17616, 0, 1),
(8, 'You must be "competent" to carry out the task. -(List Type)', 'You must be "competent" to carry out the task.', 17616, 0, 2),
(9, 'You must NOT carry out this task alone. -(List Type)', 'You must NOT carry out this task alone.', 17616, 0, 2),
(10, 'Barriers erected at entrances and around the work area if deemed necessary by the foreman or safety officer to protect tenants. -(List Type)', 'Barriers erected at entrances and around the work area if deemed necessary by the foreman or safety officer to protect tenants.', 17616, 0, 2),
(11, 'You must not lift beyond your capabilities, get help if necessary. -(List Type)', 'You must not lift beyond your capabilities, get help if necessary.', 17616, 0, 2),
(12, 'Visitors and other members of staff are prohibited from entry unless accompanied by competent person, all visitors issued with personal protective equipment. -(List Type)', 'Visitors and other members of staff are prohibited from entry unless accompanied by competent person, all visitors issued with personal protective equipment.', 17616, 0, 2),
(13, 'You must read and be familiar with the Safety Data Sheets for concrete which contains first aid, fire fighting, and accidental release measures. -(List Type)', 'You must read and be familiar with the Safety Data Sheets for concrete which contains first aid, fire fighting, and accidental release measures.', 17616, 0, 2),
(14, 'Safety Glasses -(List Type)', 'Safety Glasses.', 17616, 0, 3),
(15, 'Dust mask -(List Type)', 'Dust Mask.', 17616, 0, 3),
(16, 'Overalls -(List Type)', 'Overalls.', 17616, 0, 3),
(17, 'Gloves -(List Type)', 'Gloves.', 17616, 0, 3),
(18, 'Safety Boots -(List Type)', 'Safety Boots.', 17616, 0, 3),
(19, 'You must dispose of waste and spoil to the designated area or skip provided for waste. -(List Type)', 'You must dispose of waste and spoil to the designated area or skip provided for waste.', 17616, 0, 4),
(20, 'Adhere strictly to the following procedure to ensure quality of service. -(List Type)', 'Adhere strictly to the following procedure to ensure quality of service.', 17616, 0, 5),
(21, 'If in doubt contact your manager for clarification before proceeding. -(List Type)', 'If in doubt contact your manager for clarification before proceeding.', 17616, 0, 5),
(22, 'Drains - Block', 'This method statement describes the work process for the construction of drains.', 17616, 0, 6),
(23, 'Staff and Training - Generic Block', 'The projects will be carried out by staff from <b>YOUR COMPANY</b> All members of staff are experienced and hold the following qualifications; List Qualifications.  A site manager will be appointed to each contract who will be responsible for quality and safety.  Apprentices and young workers will be supervised and are not allowed to carry out tasks for which they have not been trained', 17616, 0, 7),
(24, 'Drains PPE - Block', 'All site workers will wear Safety boots Hi Visibility Vests, Hard Hats and protective clothing at all times, other items of PPE such as eye protection, and gloves are available to be worn as and when necessary.', 17616, 0, 8),
(25, 'Preparation and Induction - Generic Block', 'A risk assessment will be carried out for all tasks which will be discussed with members of staff and the sub contractors, any queries or concerns will be raised with the contract manager who will ensure it is dealt with.  Staff and sub contractors will be inducted onto site by the principle contractor and will follow all site rules and safety procedures.', 17616, 0, 9),
(26, 'Principal Contractor Responsible (Block)', 'The principle contractor is responsible for providing adequate washing, toilet, drying and refreshment facilities for staff and sub-contractors, staff and contractors are responsible for ensuring that such welfare facilities are maintained in a clean and wholesome manner.  This will be your responsibility when you are the principle contractor, it may be necessary occasionally for your company to identify suitable local amenities.', 17616, 0, 10),
(27, 'Sub Contractor Responsible (Block)', 'It is the responsibility of all sub contractors to ensure adequate first aid provision for its staff.  Adequate means provision of a trained first aider, suitable first aid equipment and/or the provision of an appointed person at the minimum.', 17616, 0, 11),
(28, 'Injury from incorrect Manual handling -(List type)', 'Injury from incorrect Manual handling.', 17616, 0, 1),
(29, 'Injury from slips trips and falls -(List Type)', 'Injury from slips trips and falls.', 17616, 0, 1),
(30, 'Disease from standing/stagnant water and bird fluids -(List Type)', 'Disease from standing/stagnant water and bird fluids.', 17616, 0, 1),
(31, 'Injury from the incorrect actions of other contractors on site -(List Type)', 'Injury from the incorrect actions of other contractors on site.', 17616, 0, 1),
(32, 'Injury to members of the public during operations -(List Type)', 'Injury to members of the public during operations.', 17616, 0, 1),
(33, 'Contact dermatitis from exposure to wet concrete and dust -(List Type)', 'Contact dermatitis from exposure to wet concrete and dust.', 17616, 0, 1),
(34, 'Disease from standing/stagnant water -(List Type)', 'Disease from standing/stagnant water.', 17616, 0, 1),
(35, 'Injury from machine hazards -(List Type)', 'Injury from machine hazards.', 17616, 0, 1),
(36, 'Injury due to fire -(List Type)', 'Injury due to fire.', 17616, 0, 1),
(37, 'Compressed gasses -(List Type)', 'Compressed gasses.', 17616, 0, 1),
(38, 'Ill health from breathing solder fumes -(List Type)', 'Ill health from breathing solder fumes.', 17616, 0, 1),
(39, 'Fire from hot work -(List Type)', 'Fire from hot work.', 17616, 0, 1),
(40, 'Presence of Asbestos -(List Type)', 'Presence of Asbestos.', 17616, 0, 1),
(41, 'Suspension Trauma (Falling in safety harnesses) -(List Type)', 'Suspension Trauma (Falling in safety harnesses).', 17616, 0, 1),
(42, 'Dropping equipment from MEWPS -(List Type)', 'Dropping equipment from MEWPS.', 17616, 0, 1),
(43, 'Injury from incorrect use of MEWP, overturning etc -(List Type)', 'Injury from incorrect use of MEWP, overturning etc.', 17616, 0, 1),
(44, 'Contact with hazardous dusts -(List Type)', 'Contact with hazardous dusts.', 17616, 0, 1),
(45, 'Exposure to inclement weather -(List Type)', 'Exposure to inclement weather.', 17616, 0, 1),
(46, 'Use of pressure washing machines -(List Type)', 'Use of pressure washing machines.', 17616, 0, 1),
(47, 'Severe burns/Contact dermatitis from exposure to wet concrete and dust -(List Type)', 'Severe burns/Contact dermatitis from exposure to wet concrete and dust.', 17616, 0, 1),
(48, 'Injury from machine and vehicle movement -(List Type)', 'Injury from machine and vehicle movement.', 17616, 0, 1),
(49, 'Use of power hand tools -(List Type)', 'Use of power hand tools.', 17616, 0, 1),
(50, 'Vibration -(List Type)', 'Vibration.', 17616, 0, 1),
(51, 'Injury from falling debris -(List Type)', 'Injury from falling debris.', 17616, 0, 1),
(52, 'Injury falling from step ladders -(List Type)', 'Injury falling from step ladders.', 17616, 0, 1),
(53, 'Injury to site workers due to demolition -(List Type)', 'Injury to site workers due to demolition.', 17616, 0, 1),
(54, 'Asbestos in buildings built before 2000 -(List Type)', 'Asbestos in buildings built before 2000.', 17616, 0, 1),
(55, 'Injury from contact with Electricity -(List Type)', 'Injury from contact with Electricity.', 17616, 0, 1),
(56, 'Using hoisting equipment (Genie lifts) -(List Type)', 'Using hoisting equipment (Genie lifts).', 17616, 0, 1),
(57, 'Contact with Portland Cement products -(List Type)', 'Contact with Portland Cement products.', 17616, 0, 1),
(58, 'Splinters from working with wood -(List Type)', 'Splinters from working with wood.', 17616, 0, 1),
(59, 'Injury from working with gas powered nail guns -(List Type)', 'Injury from working with gas powered nail guns.', 17616, 0, 1),
(60, 'Noise -(List Type)', 'Noise', 17616, 0, 1),
(61, 'Hand Arm Vibration -(List Type)', 'Hand Arm Vibration.', 17616, 0, 1),
(62, 'Electrocution/electric shocks -(List Type)', 'Electrocution/electric shocks.', 17616, 0, 1),
(63, 'Fire and explosion from hot work -(List Type)', 'Fire and explosion from hot work.', 17616, 0, 1),
(64, 'Injury from Power tool hazards (240V and battery powered equipment) -(List Type)', 'Injury from Power tool hazards (240V and battery powered equipment).', 17616, 0, 1),
(65, 'Working with Lead -(List Type)', 'Working with Lead.', 17616, 0, 1),
(66, 'MEWPS (Cherry pickers scissor lift etc)', 'MEWPS (Mobile Elevating Work Platforms) to include cherry pickers, Scissor lifts etc. Make sure that the MEWP selected is right for the job, e.g. make sure it can reach the area to be worked on without people having to stretch or reach beyond the platform barrier. MEWPS will be supplied by a competent company; the site foreman will ensure that only competent, trained staffs are allowed to use the MEWP. The area in which it is to be used must be free from overhead obstructions such as cables, power lines, girders, trees etc and the ground must be capable of taking the load. The ground must also be level. Where other activities are taking place in the area barriers will be placed to prevent contact with the MEWP.', 17616, 0, 13),
(67, 'Working from Ladders and Step Ladders', 'The majority of tasks carried out at height involve working below 2 metres from step ladders; all staff have been made aware of the dangers of working from step ladders and have been instructed on the safe use of ladders. All Staff are required to read and understand HSE leaflet INDG402 the Safe use of Ladders and Stepladders. Only competent members of staff will be allowed to work from step ladders and it is the responsibility of the site foreman to ensure conditions are safe before allowing any ladder work to take place.', 17616, 0, 14),
(68, 'Material Handling', 'All materials required for the site will be unloaded to a designated unloading and storage area, which will be away from the work area as far as, is practicable.  This area will be kept tidy to minimise trip hazards.  Materials as and when required will be collected from the storage area to the work area.    All staff will take care when handling materials.', 17616, 0, 15),
(69, 'Manual Handling', 'All staff have been instructed on the potential dangers of manual handling, and have received manual handling training.   Staff  will not lift items of tools or equipment beyond their capabilities.  Heavy or awkward items will be broken down into smaller pieces or dual lifted where this is not possible.  It is the responsibility of the site foreman to identify and control potentially dangerous manual handling situations as they occur on site on a day-to-day basis.', 17616, 0, 16),
(70, 'Working from Step Ups', 'The majority of tasks that involve working at height will be carried out using the step up, before use the floor area should be clear, free from waste and on level ground. The step up should be checked for any sign of damage before use and if damaged removed from use immediately.', 17616, 0, 17),
(71, 'Contractor/Visitor Safety', '<b>YOUR COMPANY</b> will liaise with other contractor’s staff on a day to day basis and ensure they are aware of the risks present during the works.  Staff and contractors will not leave any area of work in a dangerous condition or with risks to themselves, other contractors, tenants, or visitors, all tools and equipment will be cleared to secure storage at the completion of each shift.  Scaffold, ladders and any other access to height will be made inaccessible.', 17616, 0, 18),
(72, 'Tools and Electrical Equipment', 'All items of tools and equipment will be visually inspected on a regular basis defective or damaged equipment will be removed from service.  Electrical tools will be 110V or battery operated where possible, sub contractors will not be allowed to bring on to site any damaged or defective tools, the site foreman is responsible for ensuring all tools and equipment allowed on the site are fit for purpose.', 17616, 0, 19),
(73, 'Access egress', 'The principal contractor is responsible for providing safe access and egress to the site, <b>YOUR COMPANY</b> staff will ensure safe access and egress is maintained for themselves and other contractors in the area they are working in, good standards of housekeeping will be maintained. <b>YOUR COMPANY will be responsible for safe access and egress when you are the principal contractor.</b>', 17616, 0, 20),
(74, 'Solder Flux', 'Solder flux fumes are potentially dangerous all staff must read and understand the safety data sheet regarding solder flux.  (HSE Publication INDG248 Solder Fume and You).  It is the responsibility of the site foreman to ensure adequate ventilation where soldering is being carried out', 17616, 0, 21),
(75, 'Tenants Warning and Safety', 'All cleaning staff must ensure that they do not put at risk any member of the public or staff from client organisations during cleaning operations, special care will be taken where children are present.  Where cleaning takes place on the public pavement, staff will erect warning signs and barriers to prevent passers by from entering the danger area, staff will use a ground man wherever necessary.', 17616, 0, 22),
(76, 'You must follow all directions given by senior staff -(List Type)', 'You must follow all directions given by senior staff.', 17616, 0, 2),
(77, 'Warning signs must be placed at the entrance to the building and work area to prevent unauthorised persons entering -(List Type)', 'Warning signs must be placed at the entrance to the building and work area to prevent unauthorised persons entering.', 17616, 0, 2),
(78, 'You must ensure suitable ventilation during works -(List Type)', 'You must ensure suitable ventilation during works.', 17616, 0, 2),
(79, 'Ask the client to remove any valuables from the area -(List Type)', 'Ask the client to remove any valuables from the area.', 17616, 0, 2),
(80, 'Fire extinguishers will be on hand during hot work -(List Type)', 'Fire extinguishers will be on hand during hot work.', 17616, 0, 2),
(81, 'Protective heat shields must be used -(List Type)', 'Protective heat shields must be used.', 17616, 0, 2),
(82, 'You must have received asbestos awareness training -(List Type)', 'You must have received asbestos awareness training.', 17616, 0, 2),
(83, 'You must hold the appropriate license for operating MEWPS -(List Type)', 'You must hold the appropriate license for operating MEWPS.', 17616, 0, 2),
(84, 'u must ensure the area is safe to work in and left safe for other contractors -(List Type)', 'You must ensure the area is safe to work in and left safe for other contractors.', 17616, 0, 2),
(85, 'You must be trained and competent to use power tools -(List Type)', 'You must be trained and competent to use power tools.', 17616, 0, 2),
(86, 'You must read and understand the COSHH information for Portland cement products and any preservatives you are using -(List Type)', 'You must read and understand the COSHH information for Portland cement products and any preservatives you are using.', 17616, 0, 2),
(87, 'You must be Gas Safe registered to work on gas installations -(List Type)', 'You must be Gas Safe registered to work on gas installations.', 17616, 0, 2),
(88, 'You must keep a fire extinguisher nearby during hot works -(List Type)', 'You must keep a fire extinguisher nearby during hot works.', 17616, 0, 2),
(89, 'All electrical works must be isolated prior to starting work -(List Type)', 'All electrical works must be isolated prior to starting work.', 17616, 0, 2),
(90, 'Refer to the asbestos register, if none available assume that asbestos is present in buildings build before 2000  -(List Type)', 'Refer to the asbestos register, if none available assume that asbestos is present in buildings build before 2000.', 17616, 0, 2),
(91, 'Hi Vis -(List Type)', 'Hi Vis.', 17616, 0, 3),
(92, 'Overalls (fire retardant) -(List Type)', 'Overalls (fire retardant).', 17616, 0, 3),
(93, 'Gloves (fire retardant) -(List Type)', 'Gloves (fire retardant).', 17616, 0, 3),
(94, 'Hard Hats -(List Type)', 'Hard Hats.', 17616, 0, 3),
(95, 'Protective Overall. (Type 5 for asbestos) -(List Type)', 'Protective Overall. (Type 5 for asbestos).', 17616, 0, 3),
(96, 'Protective Neoprene or PVC Gloves -(List Type)', 'Protective Neoprene or PVC Gloves.', 17616, 0, 3),
(97, 'Dust mask (FFP3) -(List Type)', 'Dust mask (FFP3).', 17616, 0, 3),
(98, 'Masks appropriate for chemical cleaning and mortar dust protection -(List Type)', 'Masks appropriate for chemical cleaning and mortar dust protection.', 17616, 0, 3),
(99, 'Safety Face Visor -(List Type)', 'Safety Face Visor.', 17616, 0, 3),
(100, 'Waterproof Overalls -(List Type)', 'Waterproof Overalls.', 17616, 0, 3),
(101, 'Waterproof Gloves -(List Type)', 'Waterproof Gloves.', 17616, 0, 3),
(102, 'Safety Wellington boots -(List Type)', 'Safety Wellington boots.', 17616, 0, 3),
(103, 'Hearing Protection -(List Type)', 'Hearing Protection.', 17616, 0, 3),
(104, 'Masks appropriate for surface cleaning and mortar dust protection -(List Type)', 'Masks appropriate for surface cleaning and mortar dust protection.', 17616, 0, 3),
(105, 'Close mesh disposable overalls, RPE and disposable shoe covers where unlicensed asbestos removal is to take place -(List Type)', 'Close mesh disposable overalls, RPE and disposable shoe covers where unlicensed asbestos removal is to take place.', 17616, 0, 3),
(106, 'Hi Visibility Vests -(List Type)', 'Hi Visibility Vests.', 17616, 0, 3),
(107, 'All rubbish and waste to be will be segregated into the appropriate waste streams and taken to licensed waste control sites', 'All rubbish and waste to be will be segregated into the appropriate waste streams and taken to licensed waste control sites', 17616, 0, 4),
(108, 'You must dispose of waste and spoil to the designated area or skip provided for waste.', 'You must dispose of waste and spoil to the designated area or skip provided for waste.', 17616, 0, 4),
(109, 'You must dispose of waste via licensed waste carriers.', 'You must dispose of waste via licensed waste carriers.', 17616, 0, 4),
(110, 'Chemicals are not dangerous to the environment and are diluted before being washed off.', 'Chemicals are not dangerous to the environment and are diluted before being washed off.', 17616, 0, 4),
(111, 'If asbestos is present seek additional advice before the start of works. Refer to the refurbishment audit report.', 'If asbestos is present seek additional advice before the start of works. Refer to the refurbishment audit report.', 17616, 0, 4),
(112, 'Asbestos waste MUST BE double bagged and labelled. This waste must be removed by a licensed contractor.', 'Asbestos waste MUST BE double bagged and labelled. This waste must be removed by a licensed contractor.', 17616, 0, 4),
(113, 'Electrical - Staff/Sub Contractors (Block)', 'This project will be carried out by staff and sub-contractors to <b>YOUR COMPANY</b<. All members of staff are experienced time served electricians and are all fully qualified <b>YOUR QUALIFICATIONS</b>.  <b>YOUR COMPANY</b> has an ongoing program of training.  A site manager will be appointed to each contract who will be responsible for quality and safety.  Apprentices and young workers will be supervised and are not allowed to carry out tasks or operate machinery for which they have not been trained.', 17616, 0, 7),
(114, 'Burning / Fabricating (Block)', 'All members of staff are experienced tradesmen with previous experience of fabricating work. Apprentices and young workers will be supervised and are not allowed to carry out tasks for which they have not been trained.', 17616, 0, 7),
(115, 'Plumbing / Maintenence (Block)', 'Plumbing and maintenance work will be carried out by staff from <b>COMPANY</b>, all staff are time served plumbers with relevant experience, and hold the following qualifications; <b>LIST QUALIFICATIONS</b>.  A site manager will be appointed to each contract who will be responsible for quality and safety.  Apprentices and young workers will be supervised and are not allowed to carry out tasks or operate machinery for which they have not been trained. All site workers will wear Safety boots, and protective clothing at all times, other items of PPE such as eye protection and gloves are available to be worn as and when necessary', 17616, 0, 7),
(116, 'Stone / Surface (Block)', 'Staff from <b>YOUR COMPANY</b> will carry out surface and preparation work, all staff have relevant experience, A site manager will be appointed to each contract that will be responsible for quality and safety.  Apprentices and young workers will be supervised and are not allowed to carry out tasks or operate machinery for which they have not been trained.', 17616, 0, 7),
(117, 'Demolition (Block)', 'The projects will be carried out by staff from <b>COMPANY NAME</b>.  All members of staff are experienced tradesmen with previous experience of demolition.  A site manager will be appointed to each contract that will be responsible for quality and safety.  Apprentices and young workers will be supervised and are not allowed to carry out tasks for which they have not been trained.  ', 17616, 0, 7),
(118, 'Building / Roofing (Block)', 'The task will be carried out by staff from <b>YOUR COMPANY</b>.  All members of staff are experienced time served tradesmen and hold relevant qualifications in Building and associated trades.<b>LIST QUALIFICATIONS</b> where appropriate  A site manager will be appointed to this contract who will be responsible for quality and safety.  Apprentices and young workers will be supervised and are not allowed to carry out tasks for which they have not been trained.', 17616, 0, 7),
(119, 'Boots/Vests/Hats – General (Block)', 'All site workers will wear Safety boots Hi Visibility Vests, Hard Hats and protective clothing at all times, other items of PPE such as eye protection, and gloves are available to be worn as and when necessary.', 17616, 0, 8),
(120, 'Building / Clean (Block)', 'All site workers will wear Safety boots Hi Visibility Vests, Hard Hats and protective clothing at all times, other items of PPE <b>required for these tasks includes: safety shoes, protective clothing, rubber gloves, dust mask, shoe covers (where carpeted) and safety glasses (if required).</b>', 17616, 0, 8),
(121, 'Burning / Fabricating (Block)', 'All site workers will wear PPE at all times. The minimum level of PPE which shall be worn is overalls, eye protection and steel toe capped boots. At times of high noise ear protection is to be worn. <b>Dust masks are available and must be worn by all staff when in the vicinity of burning work, and other times as deemed appropriate. Staff who are expected to do hot work will be provided with special fire retardant overalls and gloves. Staff are not to commence hot work without the appropriate PPE. </b>', 17616, 0, 8),
(122, 'Emergency Lighting (Block)', 'All site workers will wear Safety boots Hi Visibility Vests, Hard Hats and protective clothing at all times, other items of PPE Preparation and Induction <b>(Example text) A risk assessment will be carried out for all tasks which will be discussed with members of staff and the sub contractors, any queries or concerns will be raised with the contract manager who will ensure it is dealt with.  Staff and sub contractors will be inducted onto site by the principle contractor and will follow all site rules and safety procedures.</b>', 17616, 0, 8),
(123, 'Ground Source Heat Pump (Block)', 'All site workers will wear Safety boots Hi Visibility Vests, Hard Hats and protective clothing at all times, other items of PPE Preparation and Induction <b>(Example text) A risk assessment will be carried out for all tasks which will be discussed with members of staff and the sub contractors, any queries or concerns will be raised with the contract manager who will ensure it is dealt with.  Staff and sub contractors will be inducted onto site by the principle contractor and will follow all site rules and safety procedures.</b>', 17616, 0, 8),
(124, 'Burning / Fabricating (Block)', 'All members of staff required to work at these premises will be given copies of risk assessments and method statements, any queries or concerns will be raised with <b>YOUR COMPANY</b> who will ensure it is dealt with. Staff will follow all site rules and safety procedures at all times.', 17616, 0, 9),
(125, 'Company Responsible (Block)', '<b>YOUR COMPANY</b> is responsible for providing adequate washing, toilet, drying and refreshment facilities for staff, staff and contractors are responsible for ensuring that such welfare facilities are maintained in a clean and wholesome manner.  ', 17616, 0, 10),
(126, 'Client Responsible (Block)', 'The Client is responsible for providing adequate washing, toilet, drying and refreshment facilities for <b>COMPANY</b> staff and sub-contractors, <b>COMPANY</b> are responsible for ensuring that such welfare facilities are maintained in a clean and wholesome manner.  <b>This will be your responsibility when you are the principal contractor, it may be necessary occasionally for your company to identify suitable local amenities.</b>', 17616, 0, 10),
(127, 'Site Manager Responsible (Block)', 'The Site Manager is responsible for providing adequate washing, toilet, drying and refreshment facilities for YOUR COMPANY staff and sub-contractors.', 17616, 0, 10),
(128, 'Company Responsible (Block)', 'It is the responsibility of the company to ensure adequate first aid provision for its staff.  Adequate means provision of a trained first aider, suitable first aid equipment and/or the provision of an appointed person at the minimum. A trained first aider will be a suitable person who has attended an approved course of at least 3 days training repeated every 3 years and attended a refresher course every year in between.An Appointed Person is a person provided by the employer to take charge of the situation (e.g. to call an ambulance) if a serious injury/illness occurs in the absence of a first aider.  The Appointed Person can render emergency first aid if trained to do so.  <b>Often principal contractors will ensure sufficient first aid cover for sites under their control.</b>', 17616, 0, 11);

-- --------------------------------------------------------

--
-- Table structure for table `MaximumExposureLimits`
--

CREATE TABLE IF NOT EXISTS `MaximumExposureLimits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Methods`
--

CREATE TABLE IF NOT EXISTS `Methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `MethodStatements_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `MethodStatements_id` (`MethodStatements_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Methods`
--

INSERT INTO `Methods` (`id`, `name`, `description`, `retired`, `created_at`, `created_by`, `MethodStatements_id`) VALUES
(1, 'Preparation', '<ol>\n	<li>\n	<p>Work to be carried out during day time hours.</p>\n	</li>\n	<li>\n	<p>Operatives will wear appropriate PPE.</p>\n	</li>\n	<li>\n	<p>Equipment is checked and tested prior top each shift.</p>\n	</li>\n	<li>\n	<p>Check ground conditions are suitable.</p>\n	</li>\n	<li>\n	<p>Check Height and width restrictions.</p>\n	</li>\n	<li>\n	<p>Check for overhead cables and other obstacles.</p>\n	</li>\n	<li>\n	<p>Highway hazards - put in place appropriate management signs and cones.</p>\n	</li>\n	<li>\n	<p>Cordon off work area and put in place suitable signage.</p>\n	</li>\n</ol>\n', 0, '2016-07-20 11:40:40', 17616, 1),
(2, 'Personnel', '<ol>\n	<li>\n	<p>Any named operative who is IPAF trained, certified and deemed to be competent for the work they are expected to achieve, with the safety of those affected by the activity as there priority.</p>\n	</li>\n</ol>', 0, '2016-07-20 11:40:40', 17616, 1),
(3, 'Control measures', '<ol>\n	<li>\n	<p>All personnel have received induction training.</p>\n	</li>\n	<li>\n	<p>All personnel have site meetings with senior management regarding relevant topics.</p>\n	</li>\n	<li>\n	<p>All operative are trained to the international standard set by IPAF (International Powered Access Federation) and carry there licences for inspection.</p>\n	</li>\n	<li>\n	<p>Work will only commence if the operator is satisfied that it is safe to do so.</p>\n	</li>\n	<li>\n	<p>The operator has the authority to stop work or refuse the lift if he believes the conditions on site are unsafe, this may because of the weather, wind, conflicting site activities or the customer acting or intending to work in an unsafe manner.</p>\n	</li>\n	<li>\n	<p>The equipment is tested in accordance with the appropriate provisions (HSG (G) and latest LOLER certificates are available for inspection.</p>\n	</li>\n	<li>\n	<p>Full body harness to be worn with short lanyard attached to anchorage point in cage at all times.</p>\n	</li>\n</ol>', 0, '2016-07-20 11:40:40', 17616, 1),
(4, 'Emergency Arrangements', '<ol>\n	<li>\n	<p>Rescue procedures for working at height for failed access platform.</p>\n	</li>\n	<li>\n	<p>Failure of upper control functions while elevated: Where the normal upper control functions fail the operator will use the auxiliary controls from the basket to lower the boom to the safety of the ground.</p>\n	</li>\n	<li>\n	<p>Failure of operator to be able to operate the functions while elevated due to following reasons.<br />\n	a) Operator incapacitated.<br />\n	b) Auxiliary functions fail to operate from upper control station.</p>\n	</li>\n	<li>\n	<p>Where the operator is incapable of lowering the boom using the upper controls the appointed person from YOUR COMPANY who is familiarised in the use of the lower ground controls, will lower the platform safely to the ground using the lower ground controls.</p>\n	</li>\n	<li>\n	<p>Failure of lower ground controls.<br />\n	Where the lower ground controls fail to allow the boom to be lowered to the ground the appointed person from YOUR COMPANY will use the auxiliary ground controls to lower the boom safely to the ground.</p>\n	</li>\n	<li>\n	<p>Failure of ALL normal auxiliary lowering functions.<br />\n	appointed person from YOUR COMPANY shall approach stranded personnel from another platform attach a twin lanyard to harness connected to both cages personnel to step into working cage un clip lanyard from failed platform and descend to ground level.</p>\n	</li>\n	<li>\n	<p>Injuries - access and call emergency services.</p>\n	</li>\n</ol>\n\n', 0, '2016-07-20 11:40:40', 17616, 1),
(5, 'First aid requirements', '<ol>\n	<li>\n	<p>All operative to be briefed on the name and location of the first aider.</p>\n	</li>\n	<li>\n	<p>Accidents or first aid attention to be reported to YOUR COMPANY supervisor and entered into accident book.</p>\n	</li>\n</ol>\n\n', 0, '2016-07-20 11:40:40', 17616, 1),
(6, 'Preparation / Bird Proofing and Fouling Clean', '<ul>\n<li><p>Load all equipment required for job.</p></li>\n<li><p>Carry out vehicle safety checks.</p></li>\n<li><p>Transport equipment and staff to site.</p></li>\n<li><p>Report to site foreman and receive permit to work (where required).</p></li>\n<li><p>Put on Personal Protective Equipment.</p></li>\n<li><p>Inform all other contractors/tenants in area of start of works.</p></li>\n<li><p>Liaise with the principle contractor and other contractors to ensure safe operation.</p></li>\n<li><p>Cordon off work area if practical and necessary to do so.</p></li>\n<li><p>Ensure the area to be worked and exit points are clear of obstruction.</p></li>\n<li><p>Ensure that safe access and egress is maintained.</p></li></ul>\n', 0, '2016-07-20 11:40:40', 17616, 1),
(7, 'Bird Fouling Clean and Remove', '<ol><li><p>Dilute the water based bio-side sanitizer as per manufacturers instructions.</p></li></li>\n\n<li><p>Apply the sanitizer to the affected areas using a hand held spray.</p></li>\n\n<li><p>3. Leave for up to 30mins (depending on conditions).</p></li>\n\n<li><p>4. Scrub area down using a hand held stiff brush until all foul is removed.</p></li>\n\n<li><p>5. Rinse area down with clean water applied by hose or pressure washer.</p></li>\n\n<li><p>6. Sweep all contaminated water away.</p></li></ol>\n\n', 0, '2016-07-20 11:40:40', 17616, 1),
(8, 'Bird Proofing', '\n<ol>\n	<li>\n	<p>Visually inspect the area for suitable positioning of the netting (if workings at height follow the correct procedures).</p>\n	</li>\n	<li>\n	<p>Mark out the location points.</p>\n	</li>\n	<li>\n	<p>Drill location holes approx 10-12mm using a battery powered hand drill.</p>\n	</li>\n	<li>\n	<p>Insert eye bolt fixings and tighten as required.</p>\n	</li>\n	<li>\n	<p>Thread 2-3mm bond wire though the eye bolts and tie off.</p>\n	</li>\n	<li>\n	<p>Fix the 50x50 black knotted polythene netting using the proprietary fixings.</p>\n	</li>\n	<li>\n	<p>Trim off any excess netting.</p>\n	</li>\n	<li>\n	<p>Remove all waste, tools and equipment.</p>\n	</li>\n</ol>', 0, '2016-07-20 11:40:40', 17616, 1);

-- --------------------------------------------------------

--
-- Table structure for table `MethodSections`
--

CREATE TABLE IF NOT EXISTS `MethodSections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `MethodSectionTypes_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `MethodSheetTypes_id` (`MethodSectionTypes_id`),
  KEY `MethodSectionTypes_id` (`MethodSectionTypes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `MethodSectionTypes`
--

CREATE TABLE IF NOT EXISTS `MethodSectionTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `MethodSheets`
--

CREATE TABLE IF NOT EXISTS `MethodSheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `MethodSheets`
--

INSERT INTO `MethodSheets` (`id`, `name`, `description`, `retired`, `created_by`) VALUES
(1, 'Staff Information Sheet', 'The following method statement has been developed to provide a safe system of work and must be adhered to at all times, any significant deviation from this system must first be authorised by your manager or safety representative.  <p><strong>Please read the entire sheet before beginning the procedure, if you have any questions please contact your manager or safety representative.</strong></p>', 0, 17616),
(2, 'General Precautions', '<strong>To be observed by all staff at all times, any deviation from these control procedures must be authorised by the site foreman or safety representative.</strong>', 0, 17616);

-- --------------------------------------------------------

--
-- Table structure for table `MethodStatements`
--

CREATE TABLE IF NOT EXISTS `MethodStatements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `MethodStatements`
--

INSERT INTO `MethodStatements` (`id`, `name`, `description`, `retired`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'Bird Proofing & Fouling Clean', 'This method statement should describe the work process, E.g. For the removal Bird waste & Proofing.', 0, '2016-07-20 11:28:30', NULL, 13508, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `MethodStatement_MethodSections`
--

CREATE TABLE IF NOT EXISTS `MethodStatement_MethodSections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `MethodStatements_id` int(11) NOT NULL,
  `MethodSections_id` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `MethodStatments_id` (`MethodStatements_id`),
  KEY `MethodSections_id` (`MethodSections_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `MSSections_Headers`
--

CREATE TABLE IF NOT EXISTS `MSSections_Headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `MSSheets_Sections_id` int(11) NOT NULL,
  `Headers_id` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Sections_id` (`MSSheets_Sections_id`,`Headers_id`),
  KEY `Headers_id` (`Headers_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `MSSections_Headers`
--

INSERT INTO `MSSections_Headers` (`id`, `MSSheets_Sections_id`, `Headers_id`, `retired`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0),
(3, 1, 5, 0),
(4, 1, 6, 0),
(5, 1, 29, 0),
(6, 1, 30, 0),
(7, 2, 8, 0),
(8, 2, 9, 0),
(9, 2, 10, 0),
(10, 2, 11, 0),
(11, 2, 12, 0),
(12, 3, 14, 0),
(13, 3, 15, 0),
(14, 3, 16, 0),
(15, 3, 17, 0),
(16, 3, 18, 0),
(17, 3, 91, 0),
(18, 4, 107, 0),
(19, 5, 20, 0),
(20, 5, 21, 0),
(21, 6, 66, 0),
(22, 7, 67, 0),
(23, 8, 23, 0),
(24, 9, 119, 0),
(25, 10, 25, 0),
(26, 11, 26, 0),
(27, 12, 128, 0);

-- --------------------------------------------------------

--
-- Table structure for table `MSSheets_Sections`
--

CREATE TABLE IF NOT EXISTS `MSSheets_Sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Statements_Sheets_id` int(11) NOT NULL,
  `Sections_id` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Statements_Sheets_id` (`Statements_Sheets_id`,`Sections_id`),
  KEY `Statements_Sheets_id_2` (`Statements_Sheets_id`),
  KEY `Sections_id` (`Sections_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `MSSheets_Sections`
--

INSERT INTO `MSSheets_Sections` (`id`, `Statements_Sheets_id`, `Sections_id`, `retired`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0),
(3, 1, 3, 0),
(4, 1, 4, 0),
(5, 1, 5, 0),
(6, 2, 13, 0),
(7, 2, 14, 0),
(8, 2, 7, 0),
(9, 2, 8, 0),
(10, 2, 9, 0),
(11, 2, 10, 0),
(12, 2, 11, 0);

-- --------------------------------------------------------

--
-- Table structure for table `MSStatements_Sheets`
--

CREATE TABLE IF NOT EXISTS `MSStatements_Sheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `MethodStatements_id` int(11) NOT NULL,
  `MethodSheets_id` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `MethodStatments_id` (`MethodStatements_id`,`MethodSheets_id`),
  KEY `MethodSheets_id` (`MethodSheets_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `MSStatements_Sheets`
--

INSERT INTO `MSStatements_Sheets` (`id`, `MethodStatements_id`, `MethodSheets_id`, `retired`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `OccupationalExposureStandards`
--

CREATE TABLE IF NOT EXISTS `OccupationalExposureStandards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `PersonRisks`
--

CREATE TABLE IF NOT EXISTS `PersonRisks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `PersonRisks`
--

INSERT INTO `PersonRisks` (`id`, `name`, `retired`) VALUES
(1, 'Staff', 0),
(2, 'Public', 0),
(3, 'Young/Pregnant Workers', 0),
(4, 'Visitors', 0),
(5, 'Contractor', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Ppes`
--

CREATE TABLE IF NOT EXISTS `Ppes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `Ppes`
--

INSERT INTO `Ppes` (`id`, `name`, `image`, `retired`) VALUES
(1, 'Hand Protection', 'hand-image.jpg', 0),
(2, 'Protective Clothing', 'clothing-image.jpg', 0),
(3, 'Protective Footwear', 'footwear-image.jpg', 0),
(4, 'Safety Glasses', 'glasses-image.jpg', 0),
(5, 'Face Shield', 'face-image.jpg', 0),
(6, 'Face Mask', 'mask-image.jpg', 0),
(7, 'Respirator', 'respirator-image.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `RiskAssessments`
--

CREATE TABLE IF NOT EXISTS `RiskAssessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `RiskAssessments`
--

INSERT INTO `RiskAssessments` (`id`, `name`, `description`, `created_at`, `created_by`, `updated_at`, `updated_by`, `retired`) VALUES
(1, 'Domestic Satellite / Aerial Installations', 'Not set', '2016-07-21 11:07:29', 13508, NULL, NULL, 1),
(2, 'Domestic Satellite / Aerial Installations', 'Not set', '2016-07-21 11:07:57', 13508, NULL, NULL, 0),
(3, 'ggg', 'Not set', '2016-07-21 16:21:34', 13508, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `RiskAssessments_Hazards`
--

CREATE TABLE IF NOT EXISTS `RiskAssessments_Hazards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `RiskAssessments_id` int(11) NOT NULL,
  `Hazards_id` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `likelihood` int(3) NOT NULL,
  `severity` int(3) NOT NULL,
  `risk_ranking` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `RiskAssessments_id` (`RiskAssessments_id`),
  KEY `Hazards_id` (`Hazards_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `RiskAssessments_Hazards`
--

INSERT INTO `RiskAssessments_Hazards` (`id`, `RiskAssessments_id`, `Hazards_id`, `retired`, `likelihood`, `severity`, `risk_ranking`) VALUES
(1, 1, 1, 0, 1, 5, 0),
(2, 1, 2, 0, 1, 5, 0),
(3, 1, 3, 0, 1, 5, 0),
(4, 1, 4, 0, 2, 5, 0),
(5, 1, 5, 0, 1, 4, 0),
(6, 1, 6, 0, 1, 4, 0),
(7, 1, 7, 0, 2, 3, 0),
(8, 1, 8, 0, 1, 4, 0),
(9, 1, 9, 0, 1, 5, 0),
(10, 2, 1, 0, 1, 5, 5),
(11, 2, 2, 0, 1, 5, 5),
(12, 2, 3, 0, 1, 5, 5),
(13, 2, 4, 0, 2, 5, 10),
(14, 2, 5, 0, 1, 4, 4),
(15, 2, 6, 0, 1, 4, 4),
(16, 2, 7, 0, 2, 3, 6),
(17, 2, 8, 0, 1, 4, 4),
(18, 2, 9, 0, 1, 5, 5),
(19, 3, 3, 0, 5, 5, 25),
(20, 3, 1, 0, 4, 4, 16),
(21, 3, 2, 0, 3, 3, 9);

-- --------------------------------------------------------

--
-- Table structure for table `RiskAssessments_Hazards_Controls`
--

CREATE TABLE IF NOT EXISTS `RiskAssessments_Hazards_Controls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `RiskAssessments_Hazards_id` int(11) NOT NULL,
  `Controls_id` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `RiskAssessments_Hazards_id` (`RiskAssessments_Hazards_id`),
  KEY `Controls_id` (`Controls_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `RiskAssessments_Hazards_Controls`
--

INSERT INTO `RiskAssessments_Hazards_Controls` (`id`, `RiskAssessments_Hazards_id`, `Controls_id`, `retired`) VALUES
(1, 1, 28, 0),
(2, 1, 29, 0),
(3, 1, 30, 0),
(4, 1, 31, 0),
(5, 1, 32, 0),
(6, 1, 33, 0),
(7, 1, 34, 0),
(8, 1, 35, 0),
(9, 1, 36, 0),
(10, 2, 37, 0),
(11, 2, 38, 0),
(12, 2, 39, 0),
(13, 3, 40, 0),
(14, 4, 41, 0),
(15, 5, 42, 0),
(16, 5, 43, 0),
(17, 5, 44, 0),
(18, 6, 45, 0),
(19, 6, 46, 0),
(20, 6, 47, 0),
(21, 7, 48, 0),
(22, 7, 49, 0),
(23, 7, 50, 0),
(24, 8, 14, 0),
(25, 8, 52, 0),
(26, 8, 53, 0),
(27, 9, 54, 0),
(28, 9, 55, 0),
(29, 10, 28, 0),
(30, 10, 29, 0),
(31, 10, 30, 0),
(32, 10, 31, 0),
(33, 10, 32, 0),
(34, 10, 33, 0),
(35, 10, 34, 0),
(36, 10, 35, 0),
(37, 10, 36, 0),
(38, 11, 37, 0),
(39, 11, 38, 0),
(40, 11, 39, 0),
(41, 12, 40, 0),
(42, 13, 41, 0),
(43, 14, 42, 0),
(44, 14, 43, 0),
(45, 14, 44, 0),
(46, 15, 45, 0),
(47, 15, 46, 0),
(48, 15, 47, 0),
(49, 16, 48, 0),
(50, 16, 49, 0),
(51, 16, 50, 0),
(52, 17, 14, 0),
(53, 17, 52, 0),
(54, 17, 53, 0),
(55, 18, 54, 0),
(56, 18, 55, 0),
(57, 19, 2, 0),
(58, 19, 1, 0),
(59, 19, 3, 0),
(60, 19, 4, 0),
(61, 19, 5, 0),
(62, 20, 1, 0),
(63, 20, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `RiskAssessments_PersonRisks`
--

CREATE TABLE IF NOT EXISTS `RiskAssessments_PersonRisks` (
  `id` int(11) NOT NULL,
  `RiskAssessments_id` int(11) NOT NULL,
  `PersonRisks_id` int(11) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `RiskAssessments_id` (`RiskAssessments_id`),
  KEY `PersonRisks_id` (`PersonRisks_id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `RiskAssessments_PersonRisks`
--

INSERT INTO `RiskAssessments_PersonRisks` (`id`, `RiskAssessments_id`, `PersonRisks_id`, `retired`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0),
(3, 1, 5, 0),
(4, 2, 1, 0),
(5, 2, 2, 0),
(6, 2, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `RiskPhrases`
--

CREATE TABLE IF NOT EXISTS `RiskPhrases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=121 ;

--
-- Dumping data for table `RiskPhrases`
--

INSERT INTO `RiskPhrases` (`id`, `code`, `description`, `retired`) VALUES
(1, 'S1', 'Keep locked up.', 0),
(2, 'S2', 'Keep out of the reach of children.', 0),
(3, 'S3', 'Keep in a cool place.', 0),
(4, 'S4', 'Keep away from living quarters.', 0),
(5, 'S5', 'Keep contents under ... (there follows the name of a liquid).', 0),
(6, 'S6', 'Keep under ... (there follows the name of an inert gas).', 0),
(7, 'S7', 'Keep container tightly closed.', 0),
(8, 'S8', 'Keep container dry.', 0),
(9, 'S9', 'Keep container in a well-ventilated .place', 0),
(10, 'S12', 'Do not keep the container sealed.', 0),
(11, 'S13', 'Keep away from food, drink and animal foodstuffs.', 0),
(12, 'S14', 'Keep away from ... (a list of incompatible materials will follow).', 0),
(13, 'S15', 'Keep away from heat.', 0),
(14, 'S16', 'Keep away from sources of ignition.', 0),
(15, 'S17', 'Keep away from combustible material.', 0),
(16, 'S18', 'Handle and open container with care.', 0),
(17, 'S20', 'When using, do not eat or drink.', 0),
(18, 'S21', 'When using do not smoke.', 0),
(19, 'S22', 'Do not breathe dust.', 0),
(20, 'S23', 'Do not breathe vapour.', 0),
(21, 'S24', 'Avoid contact with skin.', 0),
(22, 'S25', 'Avoid contact with eyes.', 0),
(23, 'S26', 'In case of contact with eyes, rinse immediately with plenty of water and seek medical advice.', 0),
(24, 'S27', 'Take off immediately all contaminated clothing.', 0),
(25, 'S28', 'After contact with skin, wash immediately with plenty of soap-suds.', 0),
(26, 'S29', 'Do not empty into drains.', 0),
(27, 'S30', 'Never add water to this product.', 0),
(28, 'S33', 'Take precautionary measures against static discharges.', 0),
(29, 'S35', 'This material and its container must be disposed of in a safe way.', 0),
(30, 'S36', 'Wear suitable protective clothing.', 0),
(31, 'S37', 'Wear suitable gloves.', 0),
(32, 'S38', 'In case of insufficient ventilation, wear suitable respiratory equipment.', 0),
(33, 'S39', 'Wear eye / face protection.', 0),
(34, 'S40', 'to clean the floor and all objects contaminated by this material, use (there follows suitable cleaning material).', 0),
(35, 'S41', 'In case of fire and / or explosion do not breathe fumes.', 0),
(36, 'S42', 'During fumigation / spraying wear suitable respiratory equipment.', 0),
(37, 'S43', 'In case of fire use ... (there follows the type of fire-fighting equipment to be used.)', 0),
(38, 'S45', 'In case of accident or if you feel unwell, seek medical advice immediately (show the label whenever possible.)', 0),
(39, 'S46', 'If swallowed, seek medical advice immediately and show this container or label.', 0),
(40, 'S47', 'Keep at temperature not exceeding…', 0),
(41, 'S48', 'To be kept wet with (there follows a material name).', 0),
(42, 'S49', 'Keep only in the original container.', 0),
(43, 'S50', 'Do not mix with ...', 0),
(44, 'S51', 'Use only in well ventilated areas.', 0),
(45, 'S52', 'Not recommended for interior use on large surface areas.', 0),
(46, 'S53', 'Avoid exposure - obtain special instructions before use.', 0),
(47, 'S56', 'Dispose of this material and its container at hazardous or special waste collection point.', 0),
(48, 'S57', 'Use appropriate container to avoid environmental contamination.', 0),
(49, 'S59', 'Refer to manufacturer / supplier for information on recovery / recycling.', 0),
(50, 'S60', 'This material and its container must be disposed of as hazardous waste.', 0),
(51, 'S61', 'Avoid release to the environment. Refer to special instructions / safety data sheets.', 0),
(52, 'S62', 'If swallowed, do not induce vomiting; seek medical advice immediately and show this container or label.', 0),
(53, 'R1', 'Explosive when dry.', 0),
(54, 'R2', 'Risk of explosion by shock, friction, fire or other source of ignition.', 0),
(55, 'R3', 'Extreme risk of explosion by shock, friction, fire or other sources of ignition.', 0),
(56, 'R4', 'Forms very sensitive explosive metallic compounds.', 0),
(57, 'R5', 'Heating may cause an explosion.', 0),
(58, 'R6', 'Explosive with or without contact with air.', 0),
(59, 'R7', 'May cause fire.', 0),
(60, 'R8', 'Contact with combustible material may cause fire.', 0),
(61, 'R9', 'Explosive when mixed with combustible material.', 0),
(62, 'R10', 'Flammable.', 0),
(63, 'R11', 'Highly flammable.', 0),
(64, 'R12', 'Extremely flammable.', 0),
(65, 'R13', 'Extremely flammable liquefied gas', 0),
(66, 'R14', 'Reacts violently with water.', 0),
(67, 'R15', 'Contact with water liberates extremely flammable gases.', 0),
(68, 'R16', 'Explosive when mixed with oxidizing substances.', 0),
(69, 'R17', 'Spontaneously flammable in air.', 0),
(70, 'R18', 'In use, may form inflammable/explosive vapour-air mixture.', 0),
(71, 'R19', 'May form explosive peroxides.', 0),
(72, 'R20', 'Harmful by inhalation.', 0),
(73, 'R21', 'Harmful in contact with skin.', 0),
(74, 'R22', 'Harmful if swallowed.', 0),
(75, 'R23', 'Toxic by inhalation.', 0),
(76, 'R24', 'Toxic in contact with skin.', 0),
(77, 'R25', 'Toxic if swallowed.', 0),
(78, 'R26', 'Very toxic by inhalation.', 0),
(79, 'R27', 'Very toxic in contact with skin.', 0),
(80, 'R28', 'Very toxic if swallowed.', 0),
(81, 'R29', 'Contact with water liberates toxic gas.', 0),
(82, 'R30', 'Can become highly flammable in use.', 0),
(83, 'R31', 'Contact with acids liberates toxic gas.', 0),
(84, 'R32', 'Contact with acid liberates very toxic gas.', 0),
(85, 'R33', 'Danger of cumulative effects.', 0),
(86, 'R34', 'Causes burns.', 0),
(87, 'R35', 'Causes severe burns.', 0),
(88, 'R36', 'Irritating to eyes.', 0),
(89, 'R37', 'Irritating to respiratory system.', 0),
(90, 'R38', 'Irritating to skin.', 0),
(91, 'R39', 'Danger of very serious irreversible effects.', 0),
(92, 'R40', 'Limited evidence of a carcinogenic effect.', 0),
(93, 'R41', 'Risk of serious damage to the eyes.', 0),
(94, 'R42', 'May cause sensitization by inhalation.', 0),
(95, 'R43', 'May cause sensitization by skin contact.', 0),
(96, 'R44', 'Risk of explosion if heated under confinement.', 0),
(97, 'R45', 'May cause cancer.', 0),
(98, 'R46', 'May cause heritable genetic damage.', 0),
(99, 'R47', 'May cause birth defects', 0),
(100, 'R48', 'Danger of serious damage to health by prolonged exposure.', 0),
(101, 'R49', 'May cause cancer by inhalation.', 0),
(102, 'R50', 'Very toxic to aquatic organisms.', 0),
(103, 'R51', 'Toxic to aquatic organisms.', 0),
(104, 'R52', 'Harmful to aquatic organisms.', 0),
(105, 'R53', 'May cause long-term adverse effects in the aquatic environment.', 0),
(106, 'R54', 'Toxic to flora.', 0),
(107, 'R55', 'Toxic to fauna.', 0),
(108, 'R56', 'Toxic to soil organisms.', 0),
(109, 'R57', 'Toxic to bees.', 0),
(110, 'R58', 'May cause long-term adverse effects in the environment.', 0),
(111, 'R59', 'Dangerous to the ozone layer.', 0),
(112, 'R60', 'May impair fertility.', 0),
(113, 'R61', 'May cause harm to the unborn child.', 0),
(114, 'R62', 'Risk of impaired fertility.', 0),
(115, 'R63', 'Possible risk of harm to the unborn child.', 0),
(116, 'R64', 'May cause harm to breastfed babies.', 0),
(117, 'R65', 'Harmful: may cause lung damage if swallowed.', 0),
(118, 'R66', 'Repeated exposure may cause skin dryness or cracking.', 0),
(119, 'R67', 'Vapours may cause drowsiness and dizziness.', 0),
(120, 'R68', 'Possible risk of irreversible effects.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `RouteEntrys`
--

CREATE TABLE IF NOT EXISTS `RouteEntrys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `RouteEntrys`
--

INSERT INTO `RouteEntrys` (`id`, `name`, `retired`) VALUES
(1, 'Inhilation', 0),
(2, 'Absorbtion', 0),
(3, 'Ingestion', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Sections`
--

CREATE TABLE IF NOT EXISTS `Sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `short_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `Sections`
--

INSERT INTO `Sections` (`id`, `name`, `retired`, `short_name`) VALUES
(1, 'The main hazards to your safety and health are; <span>(Some examples are shown here, please delete/enter your own)</span>', 0, 'The main hazards to your safety and health are'),
(2, 'Preventative Measures you must take; <span>(Some examples are shown here; please delete/enter your own)</span>', 0, 'Preventative Measures you must take'),
(3, 'Personal Protective Equipment you must wear; <span>(Some examples are shown here, please delete/enter your own)</span>', 0, 'Personal Protective Equipment you must wear'),
(4, 'Environmental Protection Measures you must take; <span>(Some examples are shown here; please delete/enter your own)</span>', 0, 'Environmental Protection Measures you must take'),
(5, 'Quality Control; <span>(Some examples are shown here, please delete/enter your own)</span>', 0, 'Quality Control'),
(6, 'Task Description  <span>(Example please delete)</span>', 0, 'Task Description'),
(7, 'Staff & Training <span>(Example text)</span>', 0, 'Staff & Training'),
(8, 'PPE <span>(Example text)</span>', 0, 'PPE'),
(9, 'Preparation & Induction <span>(Example text)</span>', 0, 'Preparation & Induction'),
(10, 'Welfare <span>(Example text)</span>', 0, 'Welfare'),
(11, 'First Aid <span>(Example text)</span>', 0, 'First Aid'),
(12, 'Other <span>(Example text)</span>', 0, 'Other'),
(13, 'MEWPS (Cherry pickers scissor lift etc)', 0, 'MEWPS'),
(14, 'Working from Ladders & Step Ladders', 0, 'Ladders & Step Ladders'),
(15, 'Material Handling', 0, 'Material Handling'),
(16, 'Manual Handling', 0, 'Manual Handling'),
(17, 'Working from Step Ups', 0, 'Step Ups'),
(18, 'Contractor/Visitor Safety', 0, 'Contractor/Visitor Safety'),
(19, 'Tools and Electrical Equipment', 0, 'Tools and Electrical Equipment'),
(20, 'Access egress', 0, 'Access egress'),
(21, 'Solder Flux', 0, 'Solder Flux'),
(22, 'Tenants Warning & Safety', 0, 'Tenants Warning & Safety'),
(23, 'Vehicle Control', 0, 'Vehicle Control'),
(24, 'Worker safety & protection of goods and décor', 0, 'Worker safety'),
(25, 'Refueling Procedure on site for plant machinery and equipment', 0, 'Refueling Procedure'),
(26, 'Machine Tool Safety', 0, 'Machine Tool Safety'),
(27, 'Portland cement', 0, 'Portland cement'),
(28, 'Use of lifting Equipment', 0, 'Use of lifting Equipment');

-- --------------------------------------------------------

--
-- Table structure for table `Substances`
--

CREATE TABLE IF NOT EXISTS `Substances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `Substances`
--

INSERT INTO `Substances` (`id`, `name`, `image`, `retired`) VALUES
(1, 'Oxidising', 'Oxidising-image.jpg', 0),
(2, 'Explosive', 'Explosive-image.jpg', 0),
(3, '(Extremely) Flammable', 'flame-image.jpg', 0),
(4, 'Toxic', 'Toxic-image.jpg', 0),
(5, 'Harmful', 'Harmful-image.jpg', 0),
(6, 'Corrosive', 'Corrosive-image.jpg', 0),
(7, 'Human Health', 'Human-Health-image.jpg', 0),
(8, 'Dangerous for environment', 'Dangerous-for-environment-image.jpg', 0),
(9, 'Gas under pressure', 'Gas-under-pressure-image.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `TimePerDays`
--

CREATE TABLE IF NOT EXISTS `TimePerDays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `TimePerDays`
--

INSERT INTO `TimePerDays` (`id`, `name`, `retired`) VALUES
(1, '1 - 5', 0),
(2, '5 - 10', 0),
(3, 'More than 10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `WorkplaceExposureLimits`
--

CREATE TABLE IF NOT EXISTS `WorkplaceExposureLimits` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `CoshhAssessments`
--
ALTER TABLE `CoshhAssessments`
  ADD CONSTRAINT `CoshhDurations_fk1` FOREIGN KEY (`Durations_id`) REFERENCES `Durations` (`id`),
  ADD CONSTRAINT `CoshhAmountUseds_fk1` FOREIGN KEY (`AmountUseds_id`) REFERENCES `AmountUseds` (`id`),
  ADD CONSTRAINT `CoshhTimePerDay_fk1` FOREIGN KEY (`TimePerDays_id`) REFERENCES `TimePerDays` (`id`);

--
-- Constraints for table `Coshh_Mel`
--
ALTER TABLE `Coshh_Mel`
  ADD CONSTRAINT `CoshhMel_fk2` FOREIGN KEY (`Eh40s_id`) REFERENCES `Eh40s` (`id`),
  ADD CONSTRAINT `CoshhMel_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Coshh_Oes`
--
ALTER TABLE `Coshh_Oes`
  ADD CONSTRAINT `CoshhOes_fk2` FOREIGN KEY (`Eh40s_id`) REFERENCES `Eh40s` (`id`),
  ADD CONSTRAINT `CoshhOes_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Coshh_PersonsAffected`
--
ALTER TABLE `Coshh_PersonsAffected`
  ADD CONSTRAINT `CoshhPersons_fk2` FOREIGN KEY (`PersonRisks_id`) REFERENCES `PersonRisks` (`id`),
  ADD CONSTRAINT `CoshhPersons_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Coshh_Ppes`
--
ALTER TABLE `Coshh_Ppes`
  ADD CONSTRAINT `CoshhPpes_fk2` FOREIGN KEY (`Ppes_id`) REFERENCES `Ppes` (`id`),
  ADD CONSTRAINT `CoshhPpes_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Coshh_RiskPhrases`
--
ALTER TABLE `Coshh_RiskPhrases`
  ADD CONSTRAINT `CoshhRiskPhrases_fk2` FOREIGN KEY (`RiskPhrases_id`) REFERENCES `RiskPhrases` (`id`),
  ADD CONSTRAINT `CoshhRiskPhrases_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Coshh_RouteEntrys`
--
ALTER TABLE `Coshh_RouteEntrys`
  ADD CONSTRAINT `CoshhRoutes_fk2` FOREIGN KEY (`RouteEntrys_id`) REFERENCES `RouteEntrys` (`id`),
  ADD CONSTRAINT `CoshhRoutes_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Coshh_Substances`
--
ALTER TABLE `Coshh_Substances`
  ADD CONSTRAINT `CoshhSubstances_fk2` FOREIGN KEY (`Substances_id`) REFERENCES `Substances` (`id`),
  ADD CONSTRAINT `CoshhSubstances_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Coshh_Wel`
--
ALTER TABLE `Coshh_Wel`
  ADD CONSTRAINT `CoshhWel_fk2` FOREIGN KEY (`Eh40s_id`) REFERENCES `Eh40s` (`id`),
  ADD CONSTRAINT `CoshhWel_fk1` FOREIGN KEY (`CoshhAssessments_id`) REFERENCES `CoshhAssessments` (`id`);

--
-- Constraints for table `Headers`
--
ALTER TABLE `Headers`
  ADD CONSTRAINT `MSHeadersTypes_FK1` FOREIGN KEY (`Types_id`) REFERENCES `Sections` (`id`);

--
-- Constraints for table `Methods`
--
ALTER TABLE `Methods`
  ADD CONSTRAINT `MethodMethodStatements_id` FOREIGN KEY (`MethodStatements_id`) REFERENCES `MethodStatements` (`id`);

--
-- Constraints for table `MethodStatement_MethodSections`
--
ALTER TABLE `MethodStatement_MethodSections`
  ADD CONSTRAINT `MethStateSect_fk1` FOREIGN KEY (`MethodStatements_id`) REFERENCES `MethodStatements` (`id`),
  ADD CONSTRAINT `MethStateSect_fk2` FOREIGN KEY (`MethodSections_id`) REFERENCES `MethodSections` (`id`);

--
-- Constraints for table `MSSections_Headers`
--
ALTER TABLE `MSSections_Headers`
  ADD CONSTRAINT `MSSectionsHeaders_FK1` FOREIGN KEY (`MSSheets_Sections_id`) REFERENCES `MSSheets_Sections` (`id`),
  ADD CONSTRAINT `MSSectionsHeaders_FK2` FOREIGN KEY (`Headers_id`) REFERENCES `Headers` (`id`);

--
-- Constraints for table `MSSheets_Sections`
--
ALTER TABLE `MSSheets_Sections`
  ADD CONSTRAINT `MSSheetsSections_fk2` FOREIGN KEY (`Sections_id`) REFERENCES `Sections` (`id`),
  ADD CONSTRAINT `MSSheetsSections_fk1` FOREIGN KEY (`Statements_Sheets_id`) REFERENCES `MSStatements_Sheets` (`id`);

--
-- Constraints for table `MSStatements_Sheets`
--
ALTER TABLE `MSStatements_Sheets`
  ADD CONSTRAINT `msStatementsSheets_fk1` FOREIGN KEY (`MethodStatements_id`) REFERENCES `MethodStatements` (`id`),
  ADD CONSTRAINT `msStatementsSheets_fk2` FOREIGN KEY (`MethodSheets_id`) REFERENCES `MethodSheets` (`id`);

--
-- Constraints for table `RiskAssessments_Hazards`
--
ALTER TABLE `RiskAssessments_Hazards`
  ADD CONSTRAINT `RAH_fk1` FOREIGN KEY (`RiskAssessments_id`) REFERENCES `RiskAssessments` (`id`),
  ADD CONSTRAINT `RAH_fk2` FOREIGN KEY (`Hazards_id`) REFERENCES `Hazards` (`id`);

--
-- Constraints for table `RiskAssessments_Hazards_Controls`
--
ALTER TABLE `RiskAssessments_Hazards_Controls`
  ADD CONSTRAINT `RAHC_fk1` FOREIGN KEY (`RiskAssessments_Hazards_id`) REFERENCES `RiskAssessments_Hazards` (`id`),
  ADD CONSTRAINT `RAHC_fk2` FOREIGN KEY (`Controls_id`) REFERENCES `Controls` (`id`);

--
-- Constraints for table `RiskAssessments_PersonRisks`
--
ALTER TABLE `RiskAssessments_PersonRisks`
  ADD CONSTRAINT `RiskAssPerons_fk1` FOREIGN KEY (`RiskAssessments_id`) REFERENCES `RiskAssessments` (`id`),
  ADD CONSTRAINT `RiskAssPerons_fk2` FOREIGN KEY (`PersonRisks_id`) REFERENCES `PersonRisks` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
