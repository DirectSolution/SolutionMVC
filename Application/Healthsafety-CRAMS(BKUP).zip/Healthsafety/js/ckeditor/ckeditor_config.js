CKEDITOR.editorConfig = function( config ) {
config.toolbarGroups = [
    { name: 'document',    groups: [ 'document' ] },
    { name: 'clipboard',   groups: [ 'clipboard' ] },
    { name: 'basicstyles', groups: [ 'basicstyles'] }

];
};