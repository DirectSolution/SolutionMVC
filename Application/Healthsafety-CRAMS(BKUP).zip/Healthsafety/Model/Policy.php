<?php

namespace SolutionMvc\Healthsafety\Model;

use SolutionMvc\Model\BaseModel;

class Policy extends BaseModel{
    public function __construct() {
        parent::__construct();
    }
}
